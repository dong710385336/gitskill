package com.mobanker.tiny.tools.netty;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * Created by liyanqin on 2016/8/2.
 * 表格操作公用方法
 */
public class ExcelUtils {

    // 根据不同的类型进行转换为String类型进行返回
    public static String getCellValue(Cell cell) {
        String cellValue = "";
        switch (cell.getCellType()) {
            case XSSFCell.CELL_TYPE_BOOLEAN:
                cellValue = String.valueOf(cell.getBooleanCellValue()).trim();// 将boolan转换为String
                break;
            case XSSFCell.CELL_TYPE_FORMULA:
                cellValue = cell.getCellFormula().trim();
                break;
            case XSSFCell.CELL_TYPE_STRING:
                cellValue = cell.getStringCellValue().trim();
                break;
            case XSSFCell.CELL_TYPE_NUMERIC:
                cellValue = String.valueOf(cell.getNumericCellValue()).trim();
                break;
        }
        return cellValue;
    }

    // //value类型：String,Date,boolean,Calendar,Date,double,RichTextString
    public static void updateExcel(File file, int sheetindex, int rows, int column, String value) {
        FileInputStream fis;
        try {
            fis = new FileInputStream(file);
            //HSSFWorkbook workbook = new HSSFWorkbook(fis);
            XSSFWorkbook workbook=new XSSFWorkbook(fis);
			/*HSSFSheet sheet = workbook.getSheetAt(sheetindex);
				HSSFRow row = sheet.getRow(rows);
				HSSFCell cell = row.getCell(column);*/

            XSSFSheet sheet = workbook.getSheetAt(sheetindex);
            XSSFRow row = sheet.getRow(rows);
            XSSFCell cell = row.getCell(column);
			/*
			 * HSSFRow row=sheet.createRow(rows); HSSFCell
			 * cell=row.createCell(column);添加新的元素
			 */
            // 这里假设对应单元格原来的类型也是String类型
            if (cell == null) {
                cell = row.createCell(column);
            }
            cell.setCellValue(value);
            fis.close();// 关闭文件输出流
            FileOutputStream fos = new FileOutputStream(file);
            workbook.write(fos);
            fos.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

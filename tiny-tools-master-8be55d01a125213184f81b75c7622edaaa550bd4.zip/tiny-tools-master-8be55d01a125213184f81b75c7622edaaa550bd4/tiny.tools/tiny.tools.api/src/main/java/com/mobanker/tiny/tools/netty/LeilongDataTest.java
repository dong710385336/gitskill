package com.mobanker.tiny.tools.netty;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mobanker.common.utils.HttpClientUtils;
import com.mobanker.framework.dto.ResponseEntity;

/**
 * 银行卡验证
 *
 * @author liyanqin
 *
 */
public class LeilongDataTest {

	/**
	 * 银行卡验证测试
	 */
	public static void leilongTestData() {
		String fileName = "F://leilong/leilongData.xlsx";
		boolean isE2007 = false;
		int sheetNum = 0;
		// 判断是否为excel2007格式
		if (fileName.endsWith("xlsx")) {
			isE2007 = true;
		}
		try {
			InputStream input = new FileInputStream(fileName);
			Workbook wb = null;
			if (isE2007) {
				wb = new XSSFWorkbook(input);
			} else {
				wb = new HSSFWorkbook(input);
			}
			Sheet sheet = wb.getSheetAt(sheetNum);// 获取第一个表单
			Iterator<Row> rows = sheet.rowIterator();// 获取第一个表单的迭代器
			Map<String, String> param = null;
			while (rows.hasNext()) {
				Row row = rows.next();// 获取行数据
				int rowNum = row.getRowNum();
				if (rowNum >= 2 && rowNum < 54) {// 从第一行开始
					Iterator<Cell> cells = row.cellIterator();// 获取第一行的迭代器
					param = new HashMap<String, String>();
					while (cells.hasNext()) {
						Cell cell = cells.next();
						int cellNum = cell.getColumnIndex();
						if (cell != null) {
							switch (cellNum) {
							case 0:
								param.put("name", ExcelUtils.getCellValue(cell));
								break;
							case 1:
								param.put("idCard", ExcelUtils.getCellValue(cell));
								break;
							case 2:
								param.put("mobile", ExcelUtils.getCellValue(cell));
								break;
							case 3:
								param.put("cardNo", ExcelUtils.getCellValue(cell));
								break;
							}
						}
					}
					Map<String, String> requestBuilder = new HashMap<String, String>();
					requestBuilder.put("Content-uid", "interface");
					HttpClientUtils.setHeader(requestBuilder);
					int resultCellNum = 4;
					String url = "http://192.168.1.61:8080/auth/api/1.0.0/";
//					url = "http://112.124.211.246:8080/auth/api/1.0.0/";
					// 中智诚
					// 黑名单
//					try {
//						Map<String, String> zzcBlackParam = new HashMap<String, String>();
//						zzcBlackParam.put("name", param.get("name"));
//						zzcBlackParam.put("pid", param.get("idCard"));
//						zzcBlackParam.put("mobile", param.get("mobile"));
//						String result = HttpClientUtils.doPost("http://192.168.1.61:8081/auth/api/1.0.0/"+"zhongzhicheng/zzcBlackListVerify", zzcBlackParam);


//						ZhongzhichengBlacklistResponse response1 = JSON.parseObject(JSONObject.parseObject(result).getString("data"), ZhongzhichengBlacklistResponse.class);
//						ResponseEntity responseEntity = JSON.parseObject(result, ResponseEntity.class);
//						Object obj = responseEntity.getData();
//						ResponseEntity res = JSONObject.parseObject(result, ResponseEntity.class);
//						JSONObject response = (JSONObject) res.getData();
//						if ("ACCEPT".equalsIgnoreCase(response.getString("result"))) {
//							ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, "0");
//						} else if ("REJECT".equalsIgnoreCase(response.getString("result"))) {
//							ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, "1");
//						}
//
//					} catch (Exception e) {
//						e.printStackTrace();
//						System.out.print(e.getMessage());
//					}
					resultCellNum++;
					// 信用评分
//					try {
//						List<ZzcCreditScore> requestList = new ArrayList<ZzcCreditScore>();
//						ZzcCreditScore creScoreReq = new ZzcCreditScore();
//
//						creScoreReq.setName(param.get("name"));
//						creScoreReq.setId_number(param.get("idCard"));
//						creScoreReq.setMobile(param.get("mobile"));
//						requestList.add(creScoreReq);
//
//						Map<String, String> zzcXypfParam = new HashMap<String, String>();
//						zzcXypfParam.put("zzcCreditScore", JSONObject.toJSONString(requestList));
//						String result = HttpClientUtils.doPost(url+"zhongzhicheng/zzcCreditScore", zzcXypfParam);
//						ResponseEntity res = JSONObject.parseObject(result, ResponseEntity.class);
//						JSONObject response = (JSONObject) res.getData();
//						String dataListStr = response.getString("dataList");
//						List<JSONObject> creditResponseList = JSON.parseObject(dataListStr, List.class);
//						if (creditResponseList != null && creditResponseList.size() > 0) {
//							JSONObject object = creditResponseList.get(0);
//							ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, object.getString("score"));
//						}
//					} catch (Exception e) {
//						e.printStackTrace();
//						System.out.print(e.getMessage());
//					}
					resultCellNum++;
					// 银联智慧
//					try {
//						Map<String, String> zhihuiParam = new HashMap<String, String>();
//						zhihuiParam.put("card", param.get("cardNo"));
//						Date dNow = new Date();
//						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//
//				        Date dBefore = new Date();
//				        Calendar calendar = Calendar.getInstance();
//				        calendar.setTime(dNow);
//				        calendar.add(Calendar.DAY_OF_MONTH, -1);
//				        dNow = calendar.getTime();
//				        calendar.add(calendar.MONTH, -6);
//				        dBefore = calendar.getTime();
//				        String dateNowStr = sdf.format(dNow);
//				        String dBeforeStr = sdf.format(dBefore);
//						zhihuiParam.put("beginDate", dBeforeStr);
//						zhihuiParam.put("endDate", dateNowStr);
//						zhihuiParam.put("checkCount", "1");
//						String result = HttpClientUtils.doPost(url + "zhihui/checkActiveCard", zhihuiParam);
//						ResponseEntity res = JSONObject.parseObject(result, ResponseEntity.class);
//						JSONObject response = (JSONObject) res.getData();
//						String resCode = response.getString("result");
//						ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum,resCode + "");
//					} catch (Exception e) {
//						e.printStackTrace();
//						System.out.print(e.getMessage());
//					}
					resultCellNum++;
					// 神州融
					// 学历
					try {
						Map<String, String> eduParam = new HashMap<String, String>();
						eduParam.put("name", param.get("name"));
						eduParam.put("documentNo", param.get("idCard"));
						eduParam.put("specifyChannelCode", param.get("shenzhourong"));
						String result = HttpClientUtils.doPost(url+"shenzhourong/eduInfo", eduParam);
						ResponseEntity res = JSONObject.parseObject(result, ResponseEntity.class);
						JSONObject response = (JSONObject) res.getData();
						ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum,response.getString("degree"));
						resultCellNum++;
						ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum,response.getString("specialty"));
						resultCellNum++;
					} catch (Exception e) {
						e.printStackTrace();
						System.out.print(e.getMessage());
						resultCellNum = resultCellNum + 2;
					}
					// 卡验证
//					try {
//						Map<String, String> bankcardParam = new HashMap<String, String>();
//						bankcardParam.put("name", param.get("name"));
//						bankcardParam.put("idCard", param.get("idCard"));
//						bankcardParam.put("accountNo", param.get("cardNo"));
////						bankcardParam.put("isForce", "1");
//						bankcardParam.put("specifyChannelCode", "shenzhourong");
//						String result = HttpClientUtils.doPost(url+"innerBankCard/bankCardVerify", bankcardParam);
//						ResponseEntity res = JSONObject.parseObject(result, ResponseEntity.class);
//						BankCardResponse response = JSONObject.toJavaObject((JSON)res.getData(),BankCardResponse.class);
//						/*if("T".equals(response.getResult())){
//							ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum,"1");
//						}else if ("F".equals(response.getResult())) {
//							ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum,"0");
//						}*/
//						ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum,response.getResult() + "");
//					} catch (Exception e) {
//						e.printStackTrace();
//						System.out.print(e.getMessage());
//					}
					resultCellNum++;
					// 前海
//					try {
//						// 好信分
//						String result = HttpClientUtils.doPost(url+"qianhai/haoXinFenVerify", param);
//						ResponseEntity res = JSONObject.parseObject(result, ResponseEntity.class);
//						JSONObject response = (JSONObject) res.getData();
//						if ("1".equals(res.getStatus()) && response != null) {
//							String recordString = response.getString("records");
//							List<JSONObject> records = JSONObject.parseObject(recordString, List.class);
//							if (records != null && records.size() > 0) {
//								ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, records.get(0).getString("credooScore"));
//							}
//						}
//					} catch (Exception e) {
//						e.printStackTrace();
//						System.out.print(e.getMessage());
//					}
//					resultCellNum++;
//					try {
//						// 常贷客
//						Map<String, String> loanParam = new HashMap<String, String>();
//						List<QianHaiLoanRequestDto> recordsDto=new ArrayList<QianHaiLoanRequestDto>();
//						QianHaiLoanRequestDto recordsParams=new QianHaiLoanRequestDto();
//						recordsParams.setIdNo(param.get("idCard"));
//						recordsParams.setIdType("0");
//						recordsParams.setName(param.get("name"));
//						recordsParams.setEntityAuthCode("12345623");
//						recordsParams.setEntityAuthDate("2015-12-14 09:17:56");
//						recordsParams.setSeqNo(BillNoUtils.GenerateBillNo());
//						recordsDto.add(recordsParams);
//						loanParam.put("recordStr", JSONObject.toJSONString(recordsDto));
//						String loanResult = HttpClientUtils.doPost(url+"qianhai/loan", loanParam);
//						ResponseEntity loanRes = JSONObject.parseObject(loanResult, ResponseEntity.class);
//
//						JSONObject loanResponse = (JSONObject) loanRes.getData();
//
//						if (loanResponse != null) {
//							String recordString = loanResponse.getString("records");
//							List<JSONObject> records = JSONObject.parseObject(recordString, List.class);
//							if (records != null) {
//								ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum,records.get(0).getString("amount"));
//							}
//						}
//					} catch (Exception e) {
//						e.printStackTrace();
//						System.out.print(e.getMessage());
//					}
//					resultCellNum++;
//					try {
//						// 黑名单
//						String blacklistResult = HttpClientUtils.doPost(url+"qianhai/blacklistVerify", param);
//						ResponseEntity blackliststRes = JSONObject.parseObject(blacklistResult, ResponseEntity.class);
//						JSONObject blackliststResponse = (JSONObject) blackliststRes.getData();
//						if (blackliststResponse != null) {
//							String recordString = blackliststResponse.getString("records");
//							List<JSONObject> records = JSONObject.parseObject(recordString, List.class);
//							if (records != null && records.size() > 0) {
//								if(records.size() == 1){
//									String erMsg = records.get(0).getString("erMsg");
//									if(erMsg.contains("未找到数据")){
//										ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, "0");
//									}else {
//										ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, "1");
//									}
//								}else {
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, "1");
//								}
//							} else {
//								ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, "0");
//							}
//						}
//					} catch (Exception e) {
//						e.printStackTrace();
//						System.out.print(e.getMessage());
//					}
//					resultCellNum++;
//					// 凭安
//					try {
//						param.put("phone", param.get("mobile"));
//						String result = HttpClientUtils.doPost(url+"trustutn/blacklistShengJi", param);
//						ResponseEntity res = JSONObject.parseObject(result, ResponseEntity.class);
//						String returnStr = (String) res.getData();
//						JSONObject returnJson = JSON.parseObject(returnStr);
//						if (returnStr != null) {
//							JSONObject dataJson = returnJson.getJSONObject("data");
//							if (dataJson != null) {
//								JSONArray othersJsons = dataJson.getJSONArray("others");   //dataJson.getJSONObject("others");
//								JSONObject othersJson = othersJsons.getJSONObject(0);
//								String seriousOverdueTime = othersJson.getString("seriousOverdueTime");
//								ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, "1");
//								resultCellNum++;
//								ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, seriousOverdueTime);
//								resultCellNum++;
//							}else{
//								resultCellNum++;
//								resultCellNum++;
//							}
//						}else{
//							resultCellNum++;
//							resultCellNum++;
//						}
//					} catch (Exception e) {
//						e.printStackTrace();
//						System.out.print(e.getMessage());
//						resultCellNum++;
//						resultCellNum++;
//					}
//
//					// 百融
//					try {
//						Map<String, String> credit100Param = new HashMap<String, String>();
//						credit100Param.put("cell", param.get("mobile"));
//						credit100Param.put("id", param.get("idCard"));
//						credit100Param.put("name", param.get("name"));
//						credit100Param.put("userId", "1381298");
//						credit100Param.put("borrowNid", BillNoUtils.GenerateBillNo());
//						String result = HttpClientUtils.doPost("http://112.124.211.246:8080/auth/api/1.0.0/"+"100credit/query", credit100Param);
//						ResponseEntity res = JSONObject.parseObject(result, ResponseEntity.class);
//						String returnStr = (String) res.getData();
//						net.sf.json.JSONObject json = net.sf.json.JSONObject.fromObject(returnStr);
//						// 获取返回参数Code
//						String code = json.getString("code");
//						if("00".equals(code)){
//							//稳定性评估
//							/*String flag_stability_c = json.getString("flag_stability_c");
//							if("1".equals(flag_stability_c)){
//								String stab_auth_key_relation = json.getString("stab_auth_key_relation");
//								ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, stab_auth_key_relation);
//							}
//							resultCellNum++;*/
//							//客制化信用评分
//							String flag_score = json.getString("flag_score");
//							if("1".equals(flag_score)){
//								String scorecust = json.getString("scorecust");
//								ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, scorecust);
//							}
//							resultCellNum++;
//							//月度收支等级
//							String flag_accountChangeMonth = json.getString("flag_accountChangeMonth");
//							if("1".equals(flag_accountChangeMonth)){
//								try{
//									String acm_m1_debit_balance = json.getString("acm_m1_debit_balance");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m1_debit_balance);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m2_debit_balance = json.getString("acm_m2_debit_balance");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m2_debit_balance);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m3_debit_balance = json.getString("acm_m3_debit_balance");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m3_debit_balance);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m1_credit_out = json.getString("acm_m1_credit_out");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m1_credit_out);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m2_credit_out = json.getString("acm_m2_credit_out");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m2_credit_out);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m3_credit_out = json.getString("acm_m3_credit_out");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m3_credit_out);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m4_credit_out = json.getString("acm_m4_credit_out");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m4_credit_out);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m5_credit_out = json.getString("acm_m5_credit_out");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m5_credit_out);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m6_credit_out = json.getString("acm_m6_credit_out");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m6_credit_out);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m7m9_credit_out = json.getString("acm_m7m9_credit_out");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m7m9_credit_out);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//								try{
//									String acm_m10m12_credit_out = json.getString("acm_m10m12_credit_out");
//									ExcelUtils.updateExcel(new File(fileName), sheetNum, rowNum, resultCellNum, acm_m10m12_credit_out);
//								}catch (Exception e){
//									e.printStackTrace();
//								}
//								resultCellNum++;
//							}
//						}
//
//					} catch (Exception e) {
//						e.printStackTrace();
//						System.out.print(e.getMessage());
//					}

				} else if (rowNum >= 4) {
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		System.out.println("跑数据开始");
		leilongTestData();
		System.out.println("跑数据结束");
	}

}

package com.test.rundata.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.shadow.policy.rundata.util.CommonsUtils;

/**
 * 
 * @author wangtao
 *
 */
public class TestThreads
{
	public static void main(String[] args)
	{
		ExecutorService pool = Executors.newFixedThreadPool(50);// 50个线程去更新
		for (int i = 0; i < 100; i++)
		{
			pool.execute(new Runnable()
			{
				@Override
				public void run()
				{
					try
					{
						CommonsUtils.getLock();
						//
						CommonsUtils.COLUMNS++;
						System.out.println("---Thread.name  [" + Thread.currentThread().getName() + "]---Thread.id  [" + Thread.currentThread().getId() + "] ---num---" + CommonsUtils.COLUMNS);
					} catch (Exception e)
					{
						System.out.println(e.getMessage());
					} finally
					{
						CommonsUtils.releaseLock();
					}
				}
			});
		}
	}
}

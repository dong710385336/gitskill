package com.test.rundata.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.shadow.policy.rundata.util.CommonsUtils;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class Test_001
{

	private static String IS_JSON = "IS_JSON";

	private static String IS_ARRAY = "IS_ARRAY";

	private static Map map_;
	private static Map levelMap;
	private static int levelNumber = 0;

	@SuppressWarnings({ "rawtypes", "unused" })
	public static void main(String[] args) throws Exception
	{
		try
		{
			levelMap = new HashMap();
			map_ = new HashMap();
			String json = "{\"channel\":\"yimei\",\"data\":\"{\\\"CODE\\\":\\\"200\\\",\\\"PHONE\\\":\\\"15038360181\\\",\\\"PROVINCE\\\":\\\"河南\\\",\\\"CITY\\\":\\\"郑州/开封\\\",\\\"RESULTS\\\":[{\\\"TYPE\\\":\\\"EMR002\\\",\\\"CYCLE\\\":\\\"2015-07-31--2017-07-31\\\",\\\"DATA\\\":[]},{\\\"TYPE\\\":\\\"EMR004\\\",\\\"CYCLE\\\":\\\"2015-07-31--2017-07-31\\\",\\\"DATA\\\":[{\\\"P_TYPE\\\":\\\"1\\\",\\\"PLATFORMCODE\\\":\\\"EM_105038\\\",\\\"APPLICATIONTIME\\\":\\\"2017/3/27 0:00:00\\\",\\\"APPLICATIONAMOUNT\\\":\\\"0W～0.2W\\\",\\\"APPLICATIONRESULT\\\":\\\" \\\"}]},{\\\"TYPE\\\":\\\"EMR007\\\",\\\"CYCLE\\\":\\\"2015-07-31--2017-07-31\\\",\\\"DATA\\\":[]},{\\\"TYPE\\\":\\\"EMR009\\\",\\\"CYCLE\\\":\\\"2015-07-31--2017-07-31\\\",\\\"DATA\\\":[]},{\\\"TYPE\\\":\\\"EMR012\\\",\\\"CYCLE\\\":\\\"2015-07-31--2017-07-31\\\",\\\"DATA\\\":[]},{\\\"TYPE\\\":\\\"EMR013\\\",\\\"CYCLE\\\":\\\"2015-07-31--2017-07-31\\\",\\\"DATA\\\":[]}]}\",\"error\":\"00000000\",\"msg\":\"请求成功\",\"status\":\"1\",\"transerialsId\":\"2017073110105511734\"}";
			// 解析数据
			// Map map = analysisJson(json);
			// rundata(map);
			// map_.put("LEVEL_MAP", levelMap);
			// levelNumber = 0;

			processData(json);
		} catch (Exception e)
		{
			e.printStackTrace();
		} finally
		{
			System.out.println(JSONObject.toJSONString(map_));
		}
	}

	/**
	 * 处理一Json条数据
	 * 
	 * @param json
	 */
	@SuppressWarnings({ "rawtypes", "unused", "unchecked" })
	private static void processData(String json)
	{
		try
		{
			// levelMap = new HashMap();
			// map_ = new HashMap();
			// 解析数据
			Map map = analysisJson(json);
			rundata(map);
			// map_.put("LEVEL_MAP", levelMap);
			levelNumber = 0;
		} catch (Exception e)
		{
			e.printStackTrace();
		} finally
		{
			System.out.println(JSONObject.toJSONString(map_));
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static void rundata(Map map)
	{
		Map levelNumberMap = new HashMap();
		List listJson = (List) map.get(IS_JSON);
		List listArray = (List) map.get(IS_ARRAY);
		map.remove(IS_JSON);
		map.remove(IS_ARRAY);

		// 填充值
		for (Object key : map.keySet())
		{
			String value = "";
			if (null != map.get(key))
			{
				value = map.get(key).toString();
			}
			levelNumberMap.put(key, value);
			// levelMap.put(key, key);
			map_.put(key, value);
		}

		// 处理Json
		if (!CollectionUtils.isEmpty(listJson))
		{
			for (Object json : listJson)
			{
				rundata(analysisJson(json.toString()));
			}
		}

		// 处理Json数组
		if (!CollectionUtils.isEmpty(listArray))
		{
			for (Object array : listArray)
			{
				List list = JSONArray.parseArray(array.toString());
				for (Object obj : list)
				{
					// rundata(analysisJson(obj.toString()));
					processData(obj.toString());
				}
			}
		}
		// 获取层级关系
		// levelNumber++;
		// map_.put(levelNumber, levelNumberMap);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static Map analysisJson(String json)
	{
		List<String> jsonList = new ArrayList<String>();
		List<String> arrayList = new ArrayList<String>();
		Map totalMap = new HashMap();
		if (StringUtils.isNotBlank(json))
		{
			Map map = JSONObject.parseObject(json, Map.class);
			for (Object key : map.keySet())
			{
				Object obj = map.get(key);
				// 判断是否Json
				if (isJson(obj.toString()))
				{
					jsonList.add(obj.toString());
				}
				// 判断是否为Array
				if (isJsonArray(obj.toString()))
				{
					arrayList.add(obj.toString());
				}
				totalMap.put(key, obj);
			}
		}
		totalMap.put(IS_JSON, jsonList);
		totalMap.put(IS_ARRAY, arrayList);
		return totalMap;

	}

	/**
	 * 判断是否为Json数组
	 * 
	 * @param strl
	 * 
	 * @return true为数组
	 */
	private static boolean isJsonArray(String jsonArray)
	{
		try
		{
			JSONArray.parseArray(jsonArray, Object.class);
		} catch (Exception e)
		{
			return false;
		}
		return true;
	}

	/**
	 * 判断字符串是否为Json
	 * 
	 * @param json
	 */
	private static boolean isJson(String json)
	{
		try
		{
			JSONObject.parseObject(json);
			return true;
		} catch (Exception e)
		{
			return false;
		}
	}

	/**
	 * 转换对象
	 * 
	 * @param obj
	 * @return
	 */
	private static Object castJson(Object obj)
	{
		Object jsonText = null;
		try
		{
			jsonText = JSONObject.parseObject(obj.toString());
		} catch (java.lang.ClassCastException e)
		{

		} catch (Exception e)
		{
			// TODO: handle exception
		}
		return jsonText;
	}

	private static void creatShell(Map map) throws Exception
	{
		// 组装数据
		File f = new File("d:" + File.separator + "test.txt");
		OutputStream os = null;
		// 创建工作薄
		WritableWorkbook workbook = null;
		try
		{
			workbook = Workbook.createWorkbook(new FileOutputStream(f));
			// 创建新的一页
			WritableSheet sheet = workbook.createSheet("sheet1", 0);
			sheet.addCell(new Label(0, CommonsUtils.COLUMNS, "ERROR"));
			workbook.write();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			if (null != workbook)
			{
				workbook.close();
			}
			if (null != os)
			{
				os.close();
			}
		}
	}
}

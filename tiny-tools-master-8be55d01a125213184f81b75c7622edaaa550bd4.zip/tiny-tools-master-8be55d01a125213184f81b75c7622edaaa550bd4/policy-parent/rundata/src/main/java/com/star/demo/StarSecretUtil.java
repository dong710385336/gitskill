package com.star.demo;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.shadow.policy.rundata.util.HttpsClientUtil;
import com.star.encrypt.utils.CoderUtil;
import com.star.encrypt.utils.RSACoderUtil;
import com.star.encrypt.utils.SecretUtil;

/**
 * Description : 加解密、加签、验签范例 Author : zouyan Date : 2017年5月12日 下午3:45:52 return
 * : void
 */
public class StarSecretUtil
{
	private static Logger logger = LoggerFactory.getLogger(StarSecretUtil.class);
	/**
	 * 以下秘钥均为demo测试用,不能用于线上环境
	 */

	private static final String SECRET = "secret";

	private static final String STAR_PUB_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCM9uR3M/4GUH5zYbR2Xkvz/0m3HeE6+wSgqbA/2YccId4DtCR7ykl0RJFNfWr/1F/fRMHq1BFn1o15RvPqHoHwxP7npsBOWGHtfYB/ucbcwBjG4zqyUNBULw4pTo/K0Fi2rOxE+sMh7ngdMFABP9UmwFnAu6fWgL3ffH03R6T3hwIDAQAB";

	private static final String MERCHANT_PUB_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDCbDd42CxqgG4POcJ1g+/l0qwd8lxfuvvzKG9CrKRubSw/ODyKqiyv3dmx5gH+XMJMJfOjil4RutIoDBHCXdyS9s9gx50GHl3NvDoOIZFa1Tvq36OZSfBIp1qOLvniKYSCiaxFOZrBiVNmVf6cLtmghzMM0paQVdOlirDlVKELCwIDAQAB";

	private static final String MERCHANT_PRI_KEY = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAMJsN3jYLGqAbg85wnWD7+XSrB3yXF+6+/Mob0KspG5tLD84PIqqLK/d2bHmAf5cwkwl86OKXhG60igMEcJd3JL2z2DHnQYeXc28Og4hkVrVO+rfo5lJ8EinWo4u+eIphIKJrEU5msGJU2ZV/pwu2aCHMwzSlpBV06WKsOVUoQsLAgMBAAECgYEAoxz1YS5D/UoojB+SVNNPRkp8WleGRk5yqKsoxRBgl8CCGbwNlux0t0tyI31r+MJLxGUmxfMFPuy0+iI+GAp1TWHWEV+t5oIdTHSEMPWHBBvOQNzPYgNLZSGWxiPiwB1XvTDJ4m9TD7DEswmm+5gJBThZV42uYHd1Hd7c6B0fI5ECQQD9lrHRQgeHZpdrBLD+FrPJKHolHHXN96nWLLKF9TY2jqIxgpNudzq/jSQ8Q1VnTw747KE8RdgRn+ZHjNDh8lJ5AkEAxEV+6Lnh8P1y08cixcEXB3I6eg9a3ADst2nRrx0KhV+LzG6IPhaLqe4rkr7CDRzghjG/hnBQiomRwTisZCjIowJAb4wGE+JTpX+/Q1gA8wPReb7QW9q1BzDWCFwI+1vtyPnc5qJlb8YKlY/kTI3h11uzXlPYaMbgUIBhrz+F8p3BIQJBAJihhrjK3RcAsgxZHwR0TUlgHnOPf1P5cByOMR8h0W24yMmY52CJPeFPMxlyOQvjegNBqrSMoUWrB+sf/IgDY0sCQQDFacRL+IfjoQgnw1BCgJpbdWj7hOkoy/l6YdY4WWKo5bDDARvJa32CUXUzazsYqLPYr7ns7ZnmQ5hbh5VWU9QM";

	public static void main(String[] args)
	{
		// 1.构建请求参数
		// =============================--卡四要素--============================================
		// JSONObject json = new JSONObject();
		// json.put("name", "付小敏");
		// json.put("mobile", "13110447150");
		// json.put("bankCardNo", "6214831291178736");
		// json.put("idCard", "142702199007290042");
		// Map<String, String> params = requestEncoder(json, "170511215037271",
		// "bankCardVerify4", "1.0");
		// =============================================================================
		// =============================--黑名单--============================================
		JSONObject blackList = new JSONObject();
		blackList.put("name", "付小敏");
		blackList.put("mobile", "13110447150");
		blackList.put("idCard", "142702199007290042");
		Map<String, String> blackParams = requestEncoder(blackList, "170511215037271", "blackList", "1.0");
		// =============================================================================
		String str = "";
		try
		{
			str = HttpsClientUtil.doPost("http://gw.xingchenzhengxin.com/openapi", blackParams, "utf-8");
			logger.info("请求认证系统,跑数据返回结果:" + str);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		//
		JSONObject jsonResponse = JSONObject.parseObject(str);
		String bizResponse = "";
		bizResponse = responseDecoder(jsonResponse);
		if (StringUtils.isNotBlank(bizResponse))
		{
			jsonResponse.put("bizResponse", bizResponse);
		}
		logger.info(JSONObject.toJSONString(jsonResponse));
	}

	/**
	 * 请求过程的加密、加签过程
	 * 
	 * @param json
	 *            请求参数字段
	 * @param merchantNo
	 *            星辰生成的商户号
	 * @param service
	 *            星辰提供的服务
	 * @param version
	 *            服务版本
	 * @return
	 */
	public static Map<String, String> requestEncoder(JSONObject json, String merchantNo, String service, String version)
	{
		try
		{
			System.out.println("加密前明文:" + json.toJSONString());
			// 2.生成对称秘钥（可以随机生成，也可以用常量）
			// String secret = (int)(Math.random() * 1000000) + "";
			String secret = SECRET;

			// 3.对请求参数对称加密
			String bizRequest = SecretUtil.encryptMode(json.toJSONString(), secret);
			System.out.println("加密后密文:" + bizRequest);

			// 4.对刚刚生成的对称秘钥进行非对称加密（秘钥为星辰的公钥）
			byte[] b = RSACoderUtil.encryptByPublicKey(secret.getBytes(), STAR_PUB_KEY);
			secret = CoderUtil.encryptBASE64(b);

			// 5.对bizRequest加签
			String sign = RSACoderUtil.sign(bizRequest.getBytes(), MERCHANT_PRI_KEY);

			// 6.构建http请求参数
			Map<String, String> param = new HashMap<String, String>();
			param.put("bizRequest", bizRequest);
			param.put("merchantNo", merchantNo);
			param.put("secret", secret);
			param.put("sign", sign);
			param.put("service", service);
			param.put("version", version);

			// 7.打印请求参数
			// System.out.println(JSON.toJSONString(param));
			return param;
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	// 响应过程的解密、验签过程
	public static String responseDecoder(JSONObject jsonObj)
	{
		try
		{
			// 模拟返回数据
			String bizResponse = jsonObj.getString("bizResponse");

			System.out.println("解密前密文:" + bizResponse);

			String sign = jsonObj.getString("sign");

			// 1.验签
			if (RSACoderUtil.verify(bizResponse.getBytes(), STAR_PUB_KEY, sign))
			{
				System.out.println("验签通过");
			} else
			{
				System.out.println("验签失败");
			}

			// 2.非对称解密bizResponse(加密数据为商户的公钥，所以解密秘钥为商户的私钥,由星辰生成商户时分配)
			String merchantPriKey = MERCHANT_PRI_KEY;

			bizResponse = new String(RSACoderUtil.decryptByPrivateKey(CoderUtil.decryptBASE64(bizResponse), merchantPriKey));

			return bizResponse;

		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

}

package com.shadow.policy.rundata.dao;

import java.util.List;

import com.shadow.policy.rundata.entity.QueryNumber;
import com.shadow.policy.rundata.entity.RefDataEntity;

public interface RefDataMapper
{
	/**
	 * 根据模板ID获取层级集合
	 * @param id
	 * @return
	 */
	public List<RefDataEntity> getExportTemplete(String id);

	/** 获取跑数据的进度 **/
	public QueryNumber querySchedule(String batchNo);

	/** 结束跑数据的进度 **/
	// public void shutdownRunData(String batchNo);

}

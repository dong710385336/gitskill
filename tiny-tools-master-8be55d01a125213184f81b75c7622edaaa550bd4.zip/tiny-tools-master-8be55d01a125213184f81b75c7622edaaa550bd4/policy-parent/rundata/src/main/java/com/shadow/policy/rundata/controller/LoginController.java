/**
 * 
 */
package com.shadow.policy.rundata.controller;

import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.shadow.policy.rundata.auth.AuthInterceptor;
import com.shadow.policy.rundata.entity.User;
import com.shadow.policy.rundata.service.UserService;

/**
 * @author chenlf
 * 
 *         2014-3-24
 */
@Controller
public class LoginController
{

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(String redirectURL, HttpServletRequest request)
	{
		ModelAndView view = new ModelAndView();
		// 把拦截前路径存下来，以便登入成功可以直接请求到登录前的页面
		view.addObject("redirectURL", redirectURL);
		view.setViewName("../login/login");
		return view;
	}

	@RequestMapping(value = "/submit", method = RequestMethod.POST)
	public String submit(String username, String password, String redirectURL, HttpServletRequest request)
	{
		String message = "";
		if (StringUtils.isNotBlank(username) && StringUtils.isNotBlank(password))
		{

			User user = userService.getUser(username);
			if (null == user)
			{
				message = "账户不存在";
				return "redirect:/login?" + URLDecoder.decode(redirectURL) + "&message=" + message;
			}
			if (!password.equals(user.getPswd()))
			{
				message = "密码不正确";
				return "redirect:/login?" + URLDecoder.decode(redirectURL) + "&message=" + message;
			}
			// 当登陆成功是，将用户信息存放到session中去
			HttpSession session = request.getSession();
			session.setAttribute(AuthInterceptor.SEESION_MEMBER, user.getName());
			session.setMaxInactiveInterval(900);// session失效时间是15分钟
			if (StringUtils.isNotBlank(redirectURL))
			{
				return "redirect:" + URLDecoder.decode(redirectURL);
			}
			return "redirect:/run/index";
		} else
		{
			if (StringUtils.isNotBlank(redirectURL))
			{
				return "redirect:/login?" + URLDecoder.decode(redirectURL);
			}
			return "redirect:/login";
		}
	}
}

package com.shadow.policy.rundata.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shadow.policy.rundata.dao.MyMapper;
import com.shadow.policy.rundata.dao.RefDataMapper;
import com.shadow.policy.rundata.entity.BatchDataEntity;
import com.shadow.policy.rundata.entity.QueryNumber;
import com.shadow.policy.rundata.entity.RefDataEntity;
import com.shadow.policy.rundata.service.ExportDataService;

@Service
public class ExportDataServiceImpl implements ExportDataService
{
	@Autowired
	private RefDataMapper refDataMapper;
	@Autowired
	private MyMapper myMapper;

	@Override
	public List<RefDataEntity> getExportTemplete(String id)
	{
		return refDataMapper.getExportTemplete(id);
	}

	@Override
	public List<BatchDataEntity> queryBatchDataEntity(BatchDataEntity batchDataEntity)
	{
		return myMapper.queryBatchDataEntityByEntity(batchDataEntity);
	}

	@Override
	public QueryNumber querySchedule(String batchNo)
	{
		return refDataMapper.querySchedule(batchNo);
	}
}

package com.shadow.policy.rundata.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.shadow.policy.rundata.entity.BatchDataEntity;
import com.shadow.policy.rundata.entity.BatchLogEntity;
import com.shadow.policy.rundata.entity.ProductTemplateEntity;
import com.shadow.policy.rundata.entity.ProductTemplateParamsEntiy;
import com.shadow.policy.rundata.entity.TestBairRong;
import com.shadow.policy.rundata.entity.User;

/**
 * @author guanliming
 *
 */
public interface MyMapper
{

	Integer queryCount(@Param("tableName")String tableName);

	void execute(Map<String, String> sql1);

	List<Map<String, String>> query(@Param("tableName")String tableName,@Param("start") String start,@Param("pageSize") String pageSize);

	void insertList(Map<String, Object> s1);

	void dropTable(@Param("tableName")String tableName);

	List<ProductTemplateParamsEntiy> queryProductTemplateParamsEntiy(@Param("templateId")String templateId);

	List<BatchDataEntity> queryBatchDataEntity(@Param("batchNo")String batchNo);

	BatchLogEntity queryBatchLog(@Param("batchNo")String batchNo);

	ProductTemplateEntity queryProductTemplate(@Param("id")String id);

	List<ProductTemplateEntity> queryProductTemplateList();

	void insertBatchLog(BatchLogEntity entity);

	void updateBatchLog(@Param("batchNo")String batchNo);

	void updateBatchData(BatchDataEntity batchDataEntity);

	/**
	 * 查询条件：batchNo,ExportStatus
	 * @param batchDataEntity
	 * @return
	 */
	List<BatchDataEntity> queryBatchDataEntityByEntity(BatchDataEntity batchDataEntity);

	/**
	 * 更新by ID
	 * @param batchDataEntity
	 */
	void updateBatchExportStatusDataById (BatchDataEntity batchDataEntity);

	/**
	 * 获取用户
	 * @param name
	 * @return
	 */
	List<User> getUser(String name);

	/**
	 * 更新批次表
	 * @param batchLogEntity
	 */
	void updateBatchLogByEntity(BatchLogEntity batchLogEntity);

	/** 查询返回list */
	List<TestBairRong> selectUsingSql(Map<String,String> map);

	/**
	 * 控制查询条数
	 * @return
	 */
	int selectLimitNum();
}

package com.shadow.policy.rundata.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.shadow.policy.rundata.dao.MyMapper;
import com.shadow.policy.rundata.entity.TestBairRong;

/**
 * 计算百融线上计费数据
 * 
 * @author wangtao
 *
 */
@Controller
@RequestMapping(value = "/test")
public class TestController
{
	private Logger logger = LoggerFactory.getLogger(BatchDataController.class);

	@Autowired
	private MyMapper mapper;

	@RequestMapping(value = "getBairongCountNum")
	@ResponseBody
	public long getBairongCountNum(HttpServletRequest request, String batchNo, Model model) throws Exception
	{

		long count = 0;
		Map<String, String> map = new HashMap<String, String>();
		map.put("sql", "select id,response_text from t_credit100_log  where status='0' limit 1000");
		List<TestBairRong> responseText = null;
		do
		{
			responseText = mapper.selectUsingSql(map);
			final CountDownLatch cdl = new CountDownLatch(responseText.size());
			for (TestBairRong testBairRong : responseText)
			{
				cdl.countDown();// 控制循环
				Map<String, String> mm = new HashMap<String, String>();
				String text = testBairRong.getResponseText();
				String id = testBairRong.getId();
				Map<String, String> feeStatus = new HashMap<String, String>();
				JSONObject json = JSONObject.parseObject(text);
				if (null == json.get("data"))
				{
					logger.error("----查询失败：{}---", text);
					mm.put("sql", "update t_credit100_log set status='2', fee_status='" + text + "'  where id='" + id + "'");
					mapper.execute(mm);
					continue;
				} else
				{

					String data = json.get("data").toString();
					JSONObject jsonData = JSONObject.parseObject(data);
					if (null != jsonData.get("flag_stability_c"))
					{
						if ("1".equals(jsonData.get("flag_stability_c")))
						{
							feeStatus.put("flag_stability_c", jsonData.get("flag_stability_c").toString());
						}
					}
					if (null != jsonData.get("flag_consumption_c"))
					{
						if ("1".equals(jsonData.get("flag_consumption_c")))
						{
							feeStatus.put("flag_consumption_c", jsonData.get("flag_consumption_c").toString());
						}
					}
					if (null != jsonData.get("flag_media_c"))
					{
						if ("1".equals(jsonData.get("flag_media_c")))
						{
							feeStatus.put("flag_media_c", jsonData.get("flag_media_c").toString());
						}
					}
					if (null != jsonData.get("flag_accountChangeMonth"))
					{
						if ("1".equals(jsonData.get("flag_accountChangeMonth")))
						{
							feeStatus.put("flag_accountChangeMonth", jsonData.get("flag_accountChangeMonth").toString());
						}
					}
					if (null != jsonData.get("flag_score"))
					{
						if ("1".equals(jsonData.get("flag_score")))
						{
							feeStatus.put("flag_score", jsonData.get("flag_score").toString());
						}
					}
					if (null != jsonData.get("flag_location"))
					{
						if ("1".equals(jsonData.get("flag_location")))
						{

							feeStatus.put("flag_location", jsonData.get("flag_location").toString());
						}
					}
					String feeStatus_ = JSONObject.toJSONString(feeStatus);
					if (feeStatus.size() > 0)
					{
						// 计费
						count++;
						logger.error("----查询到计费：{}---", feeStatus);
						mm.put("sql", "update t_credit100_log set status='1', fee_status='" + feeStatus_ + "'  where id='" + id + "'");
					} else
					{
						logger.error("----查询到未计费：{}---", feeStatus);
						mm.put("sql", "update t_credit100_log set status='1'  where id='" + id + "'");
					}
					mapper.execute(mm);
				}
			}
			cdl.await();
		} while (null != responseText && responseText.size() > 0);
		System.out.println("计费条数：" + count);
		return count;
	}

}

package com.shadow.policy.rundata.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by futingting on 2016/10/26.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ProductTemplateParamsEntiy {
	private Integer id;
	private String templateId;
	private String fieldKey;
	private String fieldName;
	private String fieldNameCn;
}

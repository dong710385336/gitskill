package com.shadow.policy.rundata.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.shadow.policy.rundata.dao.MyMapper;
import com.shadow.policy.rundata.entity.User;
import com.shadow.policy.rundata.service.UserService;

/**
 * 
 * @author wangtao
 *
 */
@Service
public class UserServiceImpl implements UserService
{

	@Autowired
	private MyMapper mapper;

	@Override
	public User getUser(String name)
	{
		List<User> user = mapper.getUser(name);
		if (!CollectionUtils.isEmpty(user))
		{
			return user.get(0);
		}
		return null;
	}

}

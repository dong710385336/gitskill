package com.shadow.policy.rundata.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author wangtao
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class QueryNumber
{
	/** 总共条数 **/
	private int totalNum;

	/** 已跑条数 **/
	private int haveRun;

	/** 剩余条数 **/
	private int lastNum;
}

package com.shadow.policy.rundata.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author guanliming
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class BatchDataEntity
{
	private Integer id;
	private String status;
	private String batchNo;
	private String param1;
	private String param2;
	private String param3;
	private String param4;
	private String param5;
	private String param6;
	private String param7;
	private String param8;
	private String param9;
	private String param10;
	private String param11;
	private String param12;
	private String param13;
	private String param14;
	private String param15;
	private String param16;
	private String param17;
	private String param18;
	private String param19;
	private String param20;
	private String response;
	private String exportStatus;
	/**
	 * 控制查询条数
	 */
	private int limitNum;

}

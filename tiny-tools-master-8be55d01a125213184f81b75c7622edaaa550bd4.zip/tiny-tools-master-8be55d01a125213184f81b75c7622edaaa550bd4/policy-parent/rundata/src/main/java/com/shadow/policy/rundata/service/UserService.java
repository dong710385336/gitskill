package com.shadow.policy.rundata.service;

import com.shadow.policy.rundata.entity.User;

public interface UserService
{
	/**
	 * 查询账户
	 * @param name
	 */
	public User getUser(String name);
}

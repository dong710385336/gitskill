package com.shadow.policy.rundata.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author guanliming
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class BatchLogEntity
{
	private Integer id;
	private String status;
	private String batchNo;
	private String templateId;
	private String executeCount;
	private String fileName;
	private String executeUser;
}

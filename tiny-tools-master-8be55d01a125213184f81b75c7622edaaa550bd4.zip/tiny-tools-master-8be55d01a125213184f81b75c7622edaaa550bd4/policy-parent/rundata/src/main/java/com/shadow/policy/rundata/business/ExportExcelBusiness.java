package com.shadow.policy.rundata.business;

import java.util.List;

import com.shadow.policy.rundata.entity.QueryNumber;
import com.shadow.policy.rundata.entity.RefDataEntity;

public interface ExportExcelBusiness
{
	public List<RefDataEntity> getExportTemplete(String id);

	public QueryNumber getLastNumber(String batchNo);
}

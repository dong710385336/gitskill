package com.shadow.policy.rundata.util;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.shadow.policy.rundata.entity.BatchDataEntity;
import com.shadow.policy.rundata.entity.RefDataEntity;

import jxl.write.Label;
import jxl.write.WritableSheet;

public class JsonUtils
{

	/**
	 * 获取所有结果的字段的机集合
	 * 
	 * @param json
	 * @param listRefDataEntity
	 * @return
	 */
	public static Map<String, Map> pareseJson(String json, List<RefDataEntity> listRefDataEntity)
	{
		Map<String, Map> map = new HashMap<String, Map>();
		//
		JSONObject resp = JSONArray.parseObject(json);
		for (RefDataEntity refDataEntity : listRefDataEntity)
		{
			// 判断数字层级
			String refId = refDataEntity.getRefId();
			// 该字段在resp的key
			String key = "";
			RefDataEntity entity = new RefDataEntity();
			// 作为该数据的上层数据放入map追溯源,refmap存放着refDataEntity的filedName由低到高的所有关联key值
			Map<String, RefDataEntity> refmap = new HashMap<String, RefDataEntity>();
			// 递归获取层级依赖关系
			if (Integer.parseInt(refId) > 0)
			{
				// entity为 refId=0 的key
				entity = getRefByRefId(refId, listRefDataEntity, refmap);
				// key = entity.getFiledName();
			} else
			{
				if (null != resp.get(refDataEntity.getFiledName()))
				{
					key = resp.get(refDataEntity.getFiledName()).toString();
				}
			}
			map.put(refDataEntity.getFiledName(), refmap);

		}
		return map;
	}

	/**
	 * 
	 * @param refMap
	 *            key: 每一个要的结果字段，value： key值得所有的依赖关系方便找到数据
	 * @param refMap.value:<String,RefDataEntity>
	 */
	public static void analyticData(Map<String, Map> refMap, String json, int size, WritableSheet sheet, String[] dataArr, Map<String, String> labelMap, BatchDataEntity batchDataEntity) throws Exception
	{
		Map<String, String> map_value = new HashMap<String, String>();
		for (int i = 0; i < size; i++)
		{
			// 装数据
			for (String key : refMap.keySet())
			{
				String labelValue = "";
				Map<String, RefDataEntity> map = refMap.get(key);// <refId,RefDataEntity>
				Map<String, String> map1 = new HashMap<String, String>();// <顺序，refId>,排好序的数据由1（最底成）开始
				//
				arraySrting(map1, map);// 获取map1排好序的数据由1（最底成）开始
				//
				if (!CollectionUtils.isEmpty(map1))
				{
					labelValue = getData(map1, json, map, key);
				} else
				{
					JSONObject valueMap = JSONArray.parseObject(json);
					if (null != valueMap.get(key))
					{
						labelValue = valueMap.get(key).toString();
					}
				}
				map_value.put(key, labelValue);
			}
		}
		// TODO 拼接数据
		addSheet(map_value, sheet, size, labelMap, batchDataEntity, dataArr, null, null, true);
	}

	/**
	 * 递归拉取数据
	 * 
	 * @param map1
	 *            <顺序，refId>,排好序的：map1=<1,12>,<2,32>
	 * @param jsonMap
	 *            返回json串
	 * @param map
	 *            <refId,RefDataEntity>
	 * @return
	 */

	private static String getData(Map<String, String> map1, String json, Map<String, RefDataEntity> map, String refKey)
	{
		String vlaue = "";
		// 拿到上层关系的value
		for (int i = 1; i <= map1.size(); i++)
		{
			String refId = map1.get(Integer.toString(i));
			RefDataEntity entity = new RefDataEntity();
			if ("0".equals(refId))
			{
				entity = map.get("1");
			} else
			{
				for (String key : map.keySet())
				{
					entity = map.get(key);
					if (refId.equals(entity.getRefId()))
					{
						// 拿到了值，返回
						break;
					}
				}
			}
			String filedName = entity.getFiledName();
			// 获取得数据
			// json串
			if (2 == entity.getParendIsArr())
			{
				if (StringUtils.isNotBlank(json))
				{
					// 上一级取得数组，下一轮也是数组形式 ,先转成数组，然后遍历数组获取某一条key值
					if (json.startsWith("["))
					{
						List<Map<String, String>> bb = JSONObject.parseObject(json, List.class);
						for (Map<String, String> b : bb)
						{
							if (null != b.get(entity.getFiledName()))
							{
								json = JSONObject.toJSON(b.get(entity.getFiledName())).toString();
								break;
							} else
							{
								json = "";
							}
						}
					} else
					{
						JSONObject resp = JSONArray.parseObject(json);
						if (null != resp.get(filedName))
						{
							json = resp.get(filedName).toString();
						} else
						{
							json = "";
						}
					}
				}
			}
			if (1 == entity.getParendIsArr())
			{
				if (StringUtils.isNotBlank(json))
				{
					// 数组
					if (json.startsWith("["))
					{
						List<Map<String, String>> bb = JSONObject.parseObject(json, List.class);
						// RefDataEntity temp = map.get(Integer.toString((i +
						// 1)));
						for (Map<String, String> b : bb)
						{
							if (null != b.get(entity.getFiledName()))
							{
								json = JSONObject.toJSON(b.get(entity.getFiledName())).toString();
								break;
							} else
							{
								json = "";
							}
						}
					}
					// json
					else
					{
						JSONObject resp = JSONArray.parseObject(json);
						if (null != resp.get(filedName))
						{
							json = resp.get(filedName).toString();
						}
					}
				}
			}
			// 最后的值
			if (i == map1.size())
			{
				vlaue = json;
			}
		}
		// 最后获取key的值
		if (StringUtils.isNotBlank(vlaue))
		{
			// 数组
			if (vlaue.startsWith("["))
			{
				List<Map<String, String>> bb = JSONObject.parseObject(vlaue, List.class);
				// RefDataEntity temp = map.get(Integer.toString((i +
				// 1)));
				for (Map<String, String> b : bb)
				{
					if (null != b.get(refKey))
					{
						vlaue = JSONObject.toJSON(b.get(refKey)).toString();
						break;
					} else
					{
						vlaue = "";
					}
				}
			} else
			{
				JSONObject valueMap = JSONArray.parseObject(vlaue);
				if (null != valueMap.get(refKey))
				{
					vlaue = valueMap.get(refKey).toString();
				} else
				{
					vlaue = "";
				}
			}
		}
		return vlaue;
	}

	/**
	 * 
	 * @param map
	 *            <顺序，refId>
	 * @param refMap
	 *            <refId,RefDataEntity>
	 */
	private static void arraySrting(Map<String, String> map, Map<String, RefDataEntity> refMap)
	{
		// 排序refId
		List<String> list = new ArrayList<String>();
		for (String key : refMap.keySet())
		{
			list.add(refMap.get(key).getRefId());
		}
		if (CollectionUtils.isEmpty(list))
		{
			return;
		}
		Collections.sort(list, Collator.getInstance(java.util.Locale.CHINA));
		int m = 1;
		for (String j : list)
		{
			map.put(Integer.toString(m), j);
			m++;
		}
		if (map.size() > 0)
		{
			String ref = map.get(1);
		}
	}

	/**
	 * 递归
	 * 
	 * 通过一个KEY值,递归拉取他的上级的依赖关系放入map
	 * 
	 * @param refId
	 *            指向的ID
	 * @param listRefDataEntity
	 *            层级关系集合
	 * @return
	 */
	private static RefDataEntity getRefByRefId(String refId, List<RefDataEntity> listRefDataEntity, Map<String, RefDataEntity> map)
	{
		for (RefDataEntity entity : listRefDataEntity)
		{
			if (Integer.parseInt(refId) == entity.getId())
			{
				// 作为该数据的上层数据放入map追溯源
				map.put(entity.getKeyId(), entity);
				//
				if ("0".equals(entity.getRefId()))
				{
					// 拉倒最顶成数据的key值
					return entity;
				} else
				{
					// 否则继续走
					getRefByRefId(entity.getRefId(), listRefDataEntity, map);
				}
			}

		}
		return null;
	}

	/**
	 * 反射获取值
	 * 
	 * @param name
	 * @return
	 */
	private static String upperFirstFormatToGet(String name)
	{
		String first = name.substring(0, 1);

		return new StringBuffer("get").append(first.toUpperCase()).append(name.substring(1, name.length())).toString();
	}

	/**
	 * 
	 * @param labelValue
	 *            拉取的值
	 * @param sheet
	 *            excel的sheet
	 * @param i
	 *            sheet的第i列
	 * @param j
	 *            sheet的第j行
	 * @param size
	 *            最大列数
	 * @param labelMap
	 *            首行的标题（列名）
	 * @param batchDataEntity
	 *            导出 数据的key，value键值对
	 * @param dataArr
	 *            需要导出数据的数组
	 * @param recursion_value
	 *            递归返回的数组的值，直接作为label
	 * @param recursion_key
	 *            递归返回的数组的key，作为判断依据
	 * @throws Exception
	 * 
	 */
	private static void addSheet(Map<String, String> map_value, WritableSheet sheet, int size, Map<String, String> labelMap, BatchDataEntity batchDataEntity, String[] dataArr, String recursion_value, String recursion_key, boolean flag)
			throws Exception
	{
		String labelValue = "";
		int i = 0;
		for (String key_ : labelMap.keySet())
		{
			if (i < (labelMap.size() - dataArr.length))
			{
				String value = labelMap.get(Integer.toString(i));
				if (null != batchDataEntity.getClass().getMethod(upperFirstFormatToGet(value)).invoke(batchDataEntity))
				{
					labelValue = batchDataEntity.getClass().getMethod(upperFirstFormatToGet(value)).invoke(batchDataEntity).toString();
				}
				Label label = new Label(i, CommonsUtils.COLUMNS, labelValue);
				sheet.addCell(label);
				i++;
			} else
			{
				break;
			}
		}
		if (null != dataArr)
		{
			// 添加勾选了查询的结果
			String labelValue_ = "";
			for (int n = i; n < labelMap.size(); n++)
			{
				String value_ = labelMap.get(Integer.toString(n));
				if (StringUtils.isNotBlank(recursion_value) && value_.equals(recursion_key))
				{
					labelValue_ = recursion_value;

				} else
				{
					labelValue_ = map_value.get(value_);
				}
				// 判断是否为数组
				boolean isArray = false;
				if (StringUtils.isNotBlank(labelValue_) && labelValue_.startsWith("[") && labelValue_.endsWith("]") && labelValue_.length() > 2)
				{
					try
					{
						JSONArray array = JSONArray.parseArray(labelValue_);
						isArray = true;
					} catch (Exception e)
					{

					}
				}
				// 如果为数组，需要生成多条数据，递归生成,flag不进入
				if (StringUtils.isNotBlank(labelValue_) && isArray && flag)
				{
					// 转换为数组
					List<String> lists = castStringToList(labelValue_);
					int k = 0;// 跳出循环
					for (String arrLableValue : lists)
					{
						if (k != 0)
						{
							CommonsUtils.COLUMNS++;// 如果第一次自增，dataArr的数据往下摞动了一层，导致COLUMNS后面的dataArr里面的数据没有加载到
							// 更新
							updateMapData(arrLableValue, map_value);
						}
						k++;
						// 控制死循环
						if (k == lists.size())
						{
							flag = false;
						}

						addSheet(map_value, sheet, size, labelMap, batchDataEntity, dataArr, arrLableValue, value_, flag);
						flag = true;
					}
				} else
				{
					Label label = new Label(n, CommonsUtils.COLUMNS, (StringUtils.isEmpty(labelValue_) ? null : labelValue_.trim()));
					sheet.addCell(label);

				}
			}
		}
	}

	/**
	 * 更新jsonMap数组的值
	 * 
	 * @param arrLableValue
	 * @param map_value
	 */
	private static void updateMapData(String arrLableValue, Map<String, String> map_value)
	{
		if (arrLableValue.startsWith("{") && arrLableValue.endsWith("}"))
		{
			JSONObject json = JSON.parseObject(arrLableValue);
			for (String s : json.keySet())
			{
				for (String key : map_value.keySet())
				{
					if (s.equals(key))
					{
						if (null != json.get(s))
						{
							map_value.put(key, json.get(s).toString());
						} else
						{
							map_value.put(key, "");
						}
					}
				}
			}
		}
	}

	/**
	 * 转换数组
	 * 
	 * @param labelValue_
	 * @return
	 */
	private static List<String> castStringToList(String labelValue_)
	{
		JSONArray array = JSONArray.parseArray(labelValue_);
		List<String> lists = new ArrayList<String>();
		if (array.size() > 0)
		{
			for (int k = 0; k < array.size(); k++)
			{
				Object obj = array.get(k);
				if (null != obj)
				{
					lists.add(obj.toString());
				}
			}
		}
		return lists;
	}

	private static void changeKey()
	{
		// todo
	}
}

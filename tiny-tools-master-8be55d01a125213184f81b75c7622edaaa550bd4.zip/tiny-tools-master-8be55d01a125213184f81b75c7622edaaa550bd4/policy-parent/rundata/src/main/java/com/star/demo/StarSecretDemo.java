package com.star.demo;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.star.encrypt.utils.CoderUtil;
import com.star.encrypt.utils.RSACoderUtil;
import com.star.encrypt.utils.SecretUtil;

/**
 * Description : 加解密、加签、验签范例 Author : zouyan Date : 2017年5月12日 下午3:45:52 return
 * : void
 */
public class StarSecretDemo
{

	/**
	 * 以下秘钥均为demo测试用,不能用于线上环境
	 */

	private static final String SECRET = "secret";

	private static final String STAR_PUB_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCM9uR3M/4GUH5zYbR2Xkvz/0m3HeE6+wSgqbA/2YccId4DtCR7ykl0RJFNfWr/1F/fRMHq1BFn1o15RvPqHoHwxP7npsBOWGHtfYB/ucbcwBjG4zqyUNBULw4pTo/K0Fi2rOxE+sMh7ngdMFABP9UmwFnAu6fWgL3ffH03R6T3hwIDAQAB";

	private static final String MERCHANT_PUB_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCmQiHNsc/A5c0SdTw0weXtAf3mgQZuvHnPS6RwcGTOFM7EAEbIEzvcwh1ug3QlZO3UJXGu/xDALXZDbdU8s2Wn5/ZgVD+MwR70L3+th+/q78hSOnBzHwKhUTSvgWn+Wg9DESaWE/cIyUsiow3YaPuQkMj4pxTnNesoIYSIXGt6dwIDAQAB";

	private static final String MERCHANT_PRI_KEY = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAKZCIc2xz8DlzRJ1PDTB5e0B/eaBBm68ec9LpHBwZM4UzsQARsgTO9zCHW6DdCVk7dQlca7/EMAtdkNt1TyzZafn9mBUP4zBHvQvf62H7+rvyFI6cHMfAqFRNK+Baf5aD0MRJpYT9wjJSyKjDdho+5CQyPinFOc16yghhIhca3p3AgMBAAECgYAL0G04gacirPG6mwwRL6oYAmk5ZPfBDLGXMmfX+ZSgNEhREzf0ZbF+SWjv/nVVZuujhJmkdsmI7nIV7osViiXx//vpZ6efu+iAN3Qzw5tZYRrSO6M9VeP3ma6TiiRMp6I3YgvSWJQ/r8KDsELW77XreklsiWV2+IxIJsYezTrcQQJBAOfAMbaIYyQQ08zz2csY3xdMkM0e2NdSLtLPW/+ddBI7k2qpeNvyWVJscJkW7wSks/dF7mkMQT4j5x+iUTybOdcCQQC3p57yGCo+b+m/ChViL8Uu1PR4SXfqfyqOU+NhtGtH1X/Ppph/LE4OI5q+Wa8Jlw64y7is2vJ8oR7eBxG5h/BhAkEAkqnEDFNmApYPpB4SkACOds1Cuj0yV5ov/cOy4iLAKSXA1nin/vHxa0MrQwcLfrHJHs0H4z0ZMP1BsHhl1ugZgwJBAJPV74Gr6B14ku2AXXQ7RfwL2nsVkN0H3qbRamEVDaK2fvsVfP4qGO8SxBbkNJ2Apo4lF5S1bqraO/G4ORFjFyECQFr4kh9BHXmYYxz3Bx9ZWtJUNHjcL38xx8BG8MQzOgEPH8p55UDbzfOzrD2ie8m6Rs+zBOhhVvTryE7MqyBqnko=";

	public static void main(String[] args)
	{
		requestEncoder();
		responseDecoder();
	}

	// 请求过程的加密、加签过程
	public static void requestEncoder()
	{
		try
		{
			// 1.构建请求参数
			JSONObject json = new JSONObject();
			json.put("name", "张三");
			json.put("mobile", "12345678901");
			json.put("idCard", "6214831291178736");

			System.out.println("加密前明文:" + json.toJSONString());

			// 2.生成对称秘钥（可以随机生成，也可以用常量）
			// String secret = (int)(Math.random() * 1000000) + "";
			String secret = SECRET;

			// 3.对请求参数对称加密
			String bizRequest = SecretUtil.encryptMode(json.toJSONString(), secret);

			System.out.println("加密后密文:" + bizRequest);

			// 4.对刚刚生成的对称秘钥进行非对称加密（秘钥为星辰的公钥）
			byte[] b = RSACoderUtil.encryptByPublicKey(secret.getBytes(), STAR_PUB_KEY);
			secret = CoderUtil.encryptBASE64(b);

			// 5.对bizRequest加签
			String sign = RSACoderUtil.sign(bizRequest.getBytes(), MERCHANT_PRI_KEY);

			// 6.构建http请求参数
			Map<String, String> param = new HashMap<String, String>();
			param.put("bizRequest", bizRequest);
			param.put("merchantNo", "星辰生成的商户号");
			param.put("secret", secret);
			param.put("sign", sign);
			param.put("service", "星辰提供的服务");
			param.put("version", "服务版本");

			// 7.打印请求参数
			System.out.println(JSON.toJSONString(param));

		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// 响应过程的解密、验签过程
	public static void responseDecoder()
	{
		try
		{
			// 模拟返回数据
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("status", "1");
			jsonObj.put("error", "00000000");
			jsonObj.put("msg", "请求成功");
			jsonObj.put("sign", "TPVU6nWh1/9z29/eTtol5oWD5RK96vIzIT15EyEvdNKBi9NaqP0EMUVMYIGTtx0dvasZI6z8GtVh/xlM7RLauJxzUtoXB8MzGSjOCxeqhzIGDz9tZcDD5UxJHpBjbSsMJOlE6sv6KAXRDJvTNDMoW69KiqCR+RhXHuwzjUPlqs8=");
			jsonObj.put("bizResponse", "JOhdIyiZAKf7s/f1XctAgpqlYoUQAICCvafzaAXlzXfoYZz//dvc8zf6D+qiZKe65tGJPsx4H2e58oSyWMotZ2E21xlLF9ARjLo/t+McpYle5gHOeJv5TCh+xocDKMVTV6k24FxBDaoIlTv+G2fn/kDwd0pZes6x51qpqIplYU8=");

			String bizResponse = jsonObj.getString("bizResponse");

			System.out.println("解密前密文:" + bizResponse);

			String sign = jsonObj.getString("sign");

			// 1.验签
			if (RSACoderUtil.verify(bizResponse.getBytes(), STAR_PUB_KEY, sign))
			{
				System.out.println("验签通过");
			} else
			{
				System.out.println("验签失败");
			}

			// 2.非对称解密bizResponse(加密数据为商户的公钥，所以解密秘钥为商户的私钥,由星辰生成商户时分配)
			String merchantPriKey = MERCHANT_PRI_KEY;

			bizResponse = new String(RSACoderUtil.decryptByPrivateKey(CoderUtil.decryptBASE64(bizResponse), merchantPriKey));

			// 打印响应结果
			System.out.println(bizResponse);

		} catch (Exception e)
		{
			e.printStackTrace();
		}

	}

}

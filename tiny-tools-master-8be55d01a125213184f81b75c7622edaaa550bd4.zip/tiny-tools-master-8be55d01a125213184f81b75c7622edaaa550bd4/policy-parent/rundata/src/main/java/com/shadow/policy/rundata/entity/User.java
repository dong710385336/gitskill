package com.shadow.policy.rundata.entity;

import lombok.Data;
import lombok.ToString;

@Data
@ToString(callSuper = true)
public class User
{
	private int id;
	/** 别名 **/
	private String nickname;
	/** 账号 **/
	private String name;
	/** 密码 **/
	private String pswd;
	/** 状态：1:有效，0:禁止登录 **/
	private int status;
}

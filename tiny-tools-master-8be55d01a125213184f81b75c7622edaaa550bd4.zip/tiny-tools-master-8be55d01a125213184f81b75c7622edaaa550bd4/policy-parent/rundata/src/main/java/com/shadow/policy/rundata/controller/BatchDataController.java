package com.shadow.policy.rundata.controller;

import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.shadow.policy.rundata.auth.AuthInterceptor;
import com.shadow.policy.rundata.entity.BatchDataEntity;
import com.shadow.policy.rundata.entity.BatchLogEntity;
import com.shadow.policy.rundata.entity.ProductTemplateEntity;
import com.shadow.policy.rundata.entity.ProductTemplateParamsEntiy;
import com.shadow.policy.rundata.request.ConfigRequest;
import com.shadow.policy.rundata.service.SqlService;
import com.shadow.policy.rundata.service.impl.Pair;
import com.shadow.policy.rundata.util.ExcelUtil;
import com.shadow.policy.rundata.util.HttpsClientUtil;
import com.shadow.policy.rundata.util.TransferUtil;
import com.star.demo.StarSecretUtil;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

/**
 * @author guanliming
 *
 */
@Controller
@RequestMapping(value = "/run")
public class BatchDataController
{

	private Logger logger = LoggerFactory.getLogger(BatchDataController.class);

	@Autowired
	private SqlService sqlService;

	/**
	 * 仅支持xlsl格式文件上傳
	 * 
	 * @param request
	 * @param file
	 * @param configRequest
	 * @return
	 */
	@RequestMapping(value = "/importExcelData")
	@ResponseBody
	public ModelAndView importExcelData(HttpServletRequest request, @RequestParam("file") MultipartFile[] files, ConfigRequest configRequest, Model model) throws Exception
	{
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute(AuthInterceptor.SEESION_MEMBER);
		String errorMesg = "errorMesg";
		if (files == null || files.length == 0 || StringUtils.isBlank(configRequest.getTemplateId()))
		{
			model.addAttribute(errorMesg, "files为null or files.length==0,TemplateId 为空");
			return new ModelAndView("fail");
		}
		// // 保存数据上传批次文件
		// BatchLogEntity batchLog =
		// sqlService.queryBatchLog(configRequest.getBatchNo());
		// batchLog.setFileNmae(files.toString());
		// batchLog.setExecuteUser(userName);
		// batchLog.setStatus("0");// 未处理
		// sqlService.updateBatchLogByEntity(batchLog);
		try
		{

			List<ProductTemplateParamsEntiy> templateParams = sqlService.queryProductTemplateParamsEntiy(configRequest.getTemplateId());
			Map<String, String> pairsMap = new HashMap<String, String>();
			for (ProductTemplateParamsEntiy productTemplateParamsEntiy : templateParams)
			{
				pairsMap.put(productTemplateParamsEntiy.getFieldName(), productTemplateParamsEntiy.getFieldKey());
			}

			Iterator<Row> rows = ExcelUtil.getRows(files[0].getInputStream(), 0);

			List<String> mainColumn = new ArrayList<String>();
			Row row = null;
			for (int i = 0; rows.hasNext(); i++)
			{
				// Map<String, String> rowData = new HashMap<String, String>();
				List<Pair> plist = new ArrayList<Pair>();
				row = rows.next();
				if (i == 0)
				{
					Iterator<Cell> cellIte = row.cellIterator();
					while (cellIte.hasNext())
					{
						mainColumn.add(ExcelUtil.getCellValue(cellIte.next()));
					}
				} else
				{
					Iterator<Cell> cellIte = row.cellIterator();
					for (int j = 0; cellIte.hasNext(); j++)
					{
						if (StringUtils.isNotBlank(pairsMap.get(mainColumn.get(0))))
							// rowData.put(pairsMap.get(mainColumn.get(0)),
							// ExcelUtil.getCellValue(cellIte.next()));
							plist.add(new Pair(pairsMap.get(mainColumn.get(j)), ExcelUtil.getCellValue(cellIte.next())));
					}
					plist.add(new Pair("batch_no", configRequest.getBatchNo()));
					Map<String, Object> m = new HashMap<String, Object>();
					m.put("tableName", "batch_data");
					m.put("entitys", plist);
					sqlService.insertList(m);
				}
			}
			BatchLogEntity entity = new BatchLogEntity();
			entity.setBatchNo(configRequest.getBatchNo());
			entity.setTemplateId(configRequest.getTemplateId());
			sqlService.insertBatchLog(entity);
		} catch (Exception e)
		{
			model.addAttribute(errorMesg, e);
			return new ModelAndView("fail");
		}
		return new ModelAndView("success");
	}

	@RequestMapping(value = "/runData")
	@ResponseBody
	public ModelAndView runData(HttpServletRequest request, String batchNo, Model model) throws Exception
	{
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute(AuthInterceptor.SEESION_MEMBER);
		String errorMesg = "errorMesg";
		if (StringUtils.isBlank(batchNo))
		{
			// throw new RuntimeException("没有batchNo");
			model.addAttribute(errorMesg, "没有batchNo");
			return new ModelAndView("fail", model.asMap());
		}
		// 保存数据上传批次文件
		BatchLogEntity batchLog_ = sqlService.queryBatchLog(batchNo);
		batchLog_.setExecuteUser(userName);
		batchLog_.setStatus("9");// 未处理
		sqlService.updateBatchLogByEntity(batchLog_);
		try
		{

			BatchLogEntity batchLog = sqlService.queryBatchLog(batchNo);
			if (null == batchLog)
			{
				throw new Exception("该批次:" + batchNo + ",没有找到数据，请确认是否正确！");
			}
			final ProductTemplateEntity pte = sqlService.queryProductTemplate(batchLog.getTemplateId());

			List<ProductTemplateParamsEntiy> templateParams = sqlService.queryProductTemplateParamsEntiy(batchLog.getTemplateId());
			Map<String, String> pairsMap = new HashMap<String, String>();
			for (ProductTemplateParamsEntiy productTemplateParamsEntiy : templateParams)
			{
				pairsMap.put(productTemplateParamsEntiy.getFieldKey(), productTemplateParamsEntiy.getFieldName());
			}

			ExecutorService pool = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
			List<BatchDataEntity> list = null;
			do
			{
				list = sqlService.queryBatchDataEntity(batchNo);
				if (CollectionUtils.isEmpty(list))
				{
					throw new Exception("该批次:" + batchNo + ",没有找到数据，请确认是否正确！");
				}
				logger.info("查询库表list集合:" + list.size());
				final CountDownLatch cdl = new CountDownLatch(list.size());
				for (final BatchDataEntity entity : list)
				{
					final Map<String, String> requestParams = new HashMap<String, String>();

					Set<Field> fieldSet = TransferUtil.getAllFieldSet(entity);
					for (Field f : fieldSet)
					{
						Object filedValue = TransferUtil.getFieldValue(entity, f);
						if (StringUtils.isNotBlank(pairsMap.get(f.getName())) && filedValue != null)
						{
							requestParams.put(pairsMap.get(f.getName()), String.valueOf(filedValue));
						}
					}
					pool.execute(new Runnable()
					{
						@Override
						public void run()
						{
							try
							{
								// 正常跑批
								// String str =
								// HttpsClientUtil.doPost(pte.getUrl(),
								// requestParams);
								// 特殊Get请求
								// String str = doGet(entity, pte);
								// POST 请求-前海-风险度查询
								// String str = doPost(entity, pte);
								// 星辰-卡四要素
								// String str = doPostStarGetway(entity, pte);
								// 星辰-黑名单
								String str = doPostStarGetwayBlackList(entity, pte);
								logger.info("请求认证系统,跑数据返回结果:" + str);
								JSONObject res = JSONObject.parseObject(str);
								BatchDataEntity batchDataEntity = new BatchDataEntity();
								batchDataEntity.setResponse(str);
								batchDataEntity.setId(entity.getId());
								// if ("1".equals(res.getString("status")) &&
								// "00000000".equals(res.getString("error")))
								if ("1".equals(res.getString("status")) && "00000000".equals(res.getString("code")))
								{
									batchDataEntity.setStatus("1");
									sqlService.updateBatchData(batchDataEntity);
								} else
								{
									batchDataEntity.setStatus("2");
									sqlService.updateBatchData(batchDataEntity);
									// sqlService.executeSql("update batch_data
									// set status=2 ,set response=" + str + "
									// where id=" + entity.getId());
								}
								cdl.countDown();
							} catch (Exception e)
							{
								sqlService.executeSql("update batch_data set status=2 where id=" + entity.getId());
								e.printStackTrace();
							}
						}
					});
				}
				cdl.await();
			} while (null != list && list.size() > 0);
			// sqlService.updateBatchLog(batchNo);
			sqlService.executeSql("update batch_log set execute_count=execute_count+1 where batch_no=" + batchNo);
			batchLog_.setStatus("1");// 批次跑批成功
		} catch (Exception e)
		{
			batchLog_.setStatus("9");// 批次跑批失败
			model.addAttribute(errorMesg, e);
			return new ModelAndView("fail");
		} finally
		{
			// 未处理
			sqlService.updateBatchLogByEntity(batchLog_);
		}
		return new ModelAndView("success");
	}

	@RequestMapping(value = "initConfig")
	public ModelAndView initConfig(Model model) throws Exception
	{
		List<ProductTemplateEntity> templates = sqlService.queryProductTemplateList();
		model.addAttribute("templates", templates);
		return new ModelAndView("templates");
	}

	@RequestMapping(value = "index")
	public ModelAndView index() throws Exception
	{
		return new ModelAndView("rundata");
	}

	@RequestMapping(value = "creatExcel")
	public void creatExcel(String id, String name, Model model, HttpServletResponse response) throws Exception
	{
		OutputStream os = response.getOutputStream();
		if (StringUtils.isEmpty(id))
		{
			throw new Exception("id不能为空");
		}
		// 创建工作薄
		WritableWorkbook workbook = Workbook.createWorkbook(os);
		// 创建新的一页
		WritableSheet sheet = workbook.createSheet("sheet1", 0);
		// 创建要显示的内容,创建一个单元格，第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容
		List<ProductTemplateParamsEntiy> templateParams = sqlService.queryProductTemplateParamsEntiy(id);
		for (int i = 0; i < templateParams.size(); i++)
		{
			Label label = new Label(i, 0, templateParams.get(i).getFieldName());
			sheet.addCell(label);
		}
		// web浏览通过MIME类型判断文件是excel类型
		response.setContentType("application/vnd.ms-excel;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		// Content-disposition属性设置成以附件方式进行下载
		response.setHeader("Content-disposition", "attachment;filename=" + new String(name.getBytes("GB2312"), "ISO_8859_1") + "_inportExcel.xls");
		workbook.write();
		workbook.close();
		os.close();
		// return new ModelAndView("rundata");
	}

	/**
	 * GET 请求
	 * 
	 * @param entity
	 * @param pte
	 * @return
	 * @throws Exception
	 */
	public String doGet(BatchDataEntity entity, ProductTemplateEntity pte) throws Exception
	{
		// [{"idNo":"362502199301266828",
		// "idType":"0","mobileNo":"13701721155","name":"张三","reasonNo":"04","model":"M0","entityAuthCode":"362502199301266828","entityAuthDate":"2015-12-14","seqNo":"1"}]
		JSONArray jsonArr = new JSONArray();// json格式的数组
		JSONObject jsonObjArr = new JSONObject();
		jsonObjArr.put("idNo", entity.getParam1());
		jsonObjArr.put("idType", entity.getParam2());
		jsonObjArr.put("mobileNo", entity.getParam3());
		jsonObjArr.put("name", entity.getParam9());
		jsonObjArr.put("reasonNo", entity.getParam5());
		jsonObjArr.put("model", entity.getParam4());
		jsonObjArr.put("entityAuthCode", entity.getParam6());
		jsonObjArr.put("entityAuthDate", entity.getParam7());
		jsonObjArr.put("seqNo", entity.getParam8());

		jsonArr.add(jsonObjArr);
		Map<String, String> params = new HashMap<String, String>();
		params.put("idNo", entity.getParam1());
		params.put("isForce", "1");
		params.put("records", jsonArr.toString());
		return HttpsClientUtil.doGet(pte.getUrl(), params, "utf-8");
	}

	/**
	 * POST 请求-前海-风险度查询
	 * 
	 * @param entity
	 * @param pte
	 * @return
	 * @throws Exception
	 */
	public String doPost(BatchDataEntity entity, ProductTemplateEntity pte) throws Exception
	{
		// [{"idNo":"362502199301266828",
		// "idType":"0","mobileNo":"13701721155","name":"张三","reasonNo":"04","model":"M0","entityAuthCode":"362502199301266828","entityAuthDate":"2015-12-14","seqNo":"1"}]
		JSONArray jsonArr = new JSONArray();// json格式的数组
		JSONObject jsonObjArr = new JSONObject();
		jsonObjArr.put("idNo", entity.getParam1());
		jsonObjArr.put("idType", entity.getParam2());
		jsonObjArr.put("mobileNo", entity.getParam5());
		jsonObjArr.put("name", entity.getParam6());
		jsonObjArr.put("entityAuthCode", entity.getParam7());
		jsonObjArr.put("entityAuthDate", entity.getParam8());
		jsonObjArr.put("seqNo", entity.getParam9());

		jsonArr.add(jsonObjArr);
		Map<String, String> params = new HashMap<String, String>();
		params.put("batchNo", "riskDegreeQuery00001");
		params.put("billNo", entity.getParam1());
		params.put("recordStr", jsonArr.toString());
		return HttpsClientUtil.doPost(pte.getUrl(), params, "utf-8");
	}

	/**
	 * POST 请求-星辰-卡四要素-调用线上网关
	 * 
	 * @param entity
	 * @param pte
	 * @return
	 * @throws Exception
	 */
	public String doPostStarGetway(BatchDataEntity entity, ProductTemplateEntity pte) throws Exception
	{
		String bizResponse = "";
		String result = "";
		try
		{

			JSONObject jsonObjArr = new JSONObject();
			jsonObjArr.put("bankCardNo", entity.getParam1());
			jsonObjArr.put("name", entity.getParam2());
			jsonObjArr.put("mobile", entity.getParam3());
			jsonObjArr.put("idCard", entity.getParam4());

			Map<String, String> params = StarSecretUtil.requestEncoder(jsonObjArr, "170511215037271", "bankCardVerify4", "1.0");
			String str = "";
			try
			{
				str = HttpsClientUtil.doPost("http://gw.xingchenzhengxin.com/openapi", params, "utf-8");
				logger.info(">>>>>>>>请求网关系统,跑数据返回结果:{}" + str);
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			//
			JSONObject jsonResponse = JSONObject.parseObject(str);
			bizResponse = StarSecretUtil.responseDecoder(jsonResponse);
			if (StringUtils.isNotBlank(bizResponse))
			{
				jsonResponse.put("bizResponse", bizResponse);
			}
			result = JSONObject.toJSONString(jsonResponse);
		} catch (Exception e)
		{
			logger.error("", e);
		}
		return result;
	}

	/**
	 * POST 请求-星辰-黑名单-调用线上网关
	 * 
	 * @param entity
	 * @param pte
	 * @return
	 * @throws Exception
	 */
	public String doPostStarGetwayBlackList(BatchDataEntity entity, ProductTemplateEntity pte) throws Exception
	{
		String bizResponse = "";
		String result = "";
		try
		{

			JSONObject jsonObjArr = new JSONObject();
			// jsonObjArr.put("bankCardNo", entity.getParam1());
			jsonObjArr.put("idCard", entity.getParam2());
			jsonObjArr.put("name", entity.getParam3());
			jsonObjArr.put("mobile", entity.getParam4());

			Map<String, String> params = StarSecretUtil.requestEncoder(jsonObjArr, "170511215037271", "blackList", "1.0");
			String str = "";
			try
			{
				str = HttpsClientUtil.doPost("http://gw.xingchenzhengxin.com/openapi", params, "utf-8");
				logger.info(">>>>>>>>请求网关系统,跑数据返回结果:{}" + str);
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			//
			JSONObject jsonResponse = JSONObject.parseObject(str);
			bizResponse = StarSecretUtil.responseDecoder(jsonResponse);
			if (StringUtils.isNotBlank(bizResponse))
			{
				jsonResponse.put("bizResponse", bizResponse);
			}
			result = JSONObject.toJSONString(jsonResponse);
		} catch (Exception e)
		{
			logger.error("", e);
		}
		return result;
	}

}

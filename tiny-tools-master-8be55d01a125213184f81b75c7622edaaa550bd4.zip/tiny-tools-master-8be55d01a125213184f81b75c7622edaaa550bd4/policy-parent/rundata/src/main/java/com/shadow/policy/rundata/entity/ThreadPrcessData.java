package com.shadow.policy.rundata.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import jxl.write.WritableSheet;
import lombok.Data;
import lombok.ToString;

/**
 * 
 * @author wangtao
 *
 */

@Data
@ToString(callSuper = true)
public class ThreadPrcessData implements Serializable
{
	private static final long serialVersionUID = -720807478055084231L;
	// 返回报文
	private String responseText;

	// 需要解析数据的个数
	private int size;

	// 页面提交数据的字段
	private String[] dataArr;

	// 依赖关系集合
	private List<RefDataEntity> listRefDataEntity;

	// 首行标题
	private Map<String, String> labelMap;

	// excel
	private WritableSheet sheet;
}

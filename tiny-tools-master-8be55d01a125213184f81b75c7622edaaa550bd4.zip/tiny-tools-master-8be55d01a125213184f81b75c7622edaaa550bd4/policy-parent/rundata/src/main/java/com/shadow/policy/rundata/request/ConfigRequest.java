package com.shadow.policy.rundata.request;

import lombok.Data;

/**
 * 配置请求
 * Created by futingting on 2016/11/30.
 */
@Data
public class ConfigRequest {

//    private String url;
    private String batchNo;
    
    
    private String templateId;
}

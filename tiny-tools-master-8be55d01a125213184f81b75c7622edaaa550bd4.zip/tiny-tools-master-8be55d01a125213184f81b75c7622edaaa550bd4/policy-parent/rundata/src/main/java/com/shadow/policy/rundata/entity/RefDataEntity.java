package com.shadow.policy.rundata.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class RefDataEntity
{
	private int id;
	/**
	 * 数值层级
	 */
	private String keyId;
	/**
	 * 判断父ID是否为数组: 0-不是，1-是
	 */
	private int parendIsArr;
	/**
	 * 字段名
	 */
	private String filedName;
	/**
	 * 字段解释
	 */
	private String filedNameCn;
	/**
	 * 0-不是，1-数组，2-json
	 */
	private String refId;
	/**
	 * 模板ID
	 */
	private String templeteId;
}

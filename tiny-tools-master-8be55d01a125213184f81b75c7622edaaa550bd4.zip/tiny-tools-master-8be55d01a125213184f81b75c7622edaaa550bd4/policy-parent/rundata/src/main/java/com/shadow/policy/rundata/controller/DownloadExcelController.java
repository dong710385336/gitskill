package com.shadow.policy.rundata.controller;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.shadow.policy.rundata.business.ExportExcelBusiness;
import com.shadow.policy.rundata.entity.BatchDataEntity;
import com.shadow.policy.rundata.entity.BatchLogEntity;
import com.shadow.policy.rundata.entity.ProductTemplateParamsEntiy;
import com.shadow.policy.rundata.entity.QueryNumber;
import com.shadow.policy.rundata.entity.RefDataEntity;
import com.shadow.policy.rundata.entity.ThreadPrcessData;
import com.shadow.policy.rundata.service.SqlService;
import com.shadow.policy.rundata.util.CommonsUtils;
import com.shadow.policy.rundata.util.JsonUtils;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

/**
 * 下载数据
 * 
 * @author wangtao
 *
 */
@Controller
@RequestMapping(value = "/run")
public class DownloadExcelController
{
	private Logger logger = LoggerFactory.getLogger(BatchDataController.class);
	@Autowired
	private ExportExcelBusiness exportExcelBusiness;
	@Autowired
	private SqlService sqlService;

	@RequestMapping(value = "choseExportExcelData")
	@ResponseBody
	public ModelAndView choseExportExcelData(HttpServletRequest request, String batchNo, Model model) throws Exception
	{
		// 获取模板
		BatchLogEntity batchLog = sqlService.queryBatchLog(batchNo);
		String templatetId = batchLog.getTemplateId();
		// 获取层级关系
		List<RefDataEntity> listRefDataEntity = exportExcelBusiness.getExportTemplete(templatetId);
		model.addAttribute("listRefDataEntity", listRefDataEntity);
		model.addAttribute("batchNo", batchNo);
		return new ModelAndView("chooseAnalysisResult");
	}

	@RequestMapping(value = "exportExcelData")
	@ResponseBody
	public ModelAndView exportExcelData(HttpServletRequest request, String batchNo, Model model, String[] dataArr, HttpServletResponse response) throws Exception
	{
		String errorMesg = "errorMesg";
		String respText = "";
		// String batchNo = configRequest.getBatchNo();
		if (StringUtils.isBlank(batchNo))
		{
			// throw new RuntimeException("没有batchNo");
			model.addAttribute(errorMesg, "没有batchNo");
			return new ModelAndView("fail", model.asMap());
		}
		//
		OutputStream os = null;
		// 创建工作薄
		WritableWorkbook workbook = null;
		final ThreadPrcessData threaddata = new ThreadPrcessData();
		try
		{
			//
			CommonsUtils.COLUMNS++;
			//
			List<BatchDataEntity> list = null;
			// 获取模板
			BatchLogEntity batchLog = sqlService.queryBatchLog(batchNo);
			if (null == batchLog)
			{
				model.addAttribute(errorMesg, "没有获取到模板");
				return new ModelAndView("fail", model.asMap());
			}
			String templatetId = batchLog.getTemplateId();
			//
			List<RefDataEntity> listRefDataEntity = exportExcelBusiness.getExportTemplete(templatetId);
			if (CollectionUtils.isEmpty(listRefDataEntity))
			{
				model.addAttribute(errorMesg, "没有获取到层级关系模板");
				return new ModelAndView("fail", model.asMap());
			}
			// 数据集合
			BatchDataEntity batchData = new BatchDataEntity();
			batchData.setBatchNo(batchNo);
			batchData.setExportStatus("0");
			os = response.getOutputStream();
			workbook = Workbook.createWorkbook(os);
			// 创建新的一页
			WritableSheet sheet = workbook.createSheet("sheet1", 0);
			ExecutorService pool = Executors.newFixedThreadPool(100);// 100个线程处理
			do
			{
				list = sqlService.queryByExportStatusAndBatchNO(batchData);
				if (CollectionUtils.isEmpty(listRefDataEntity))
				{
					model.addAttribute(errorMesg, "数据已跑完,batcho=[" + batchNo + "],或该批次没有获取到数据！");
					return new ModelAndView("fail", model.asMap());
				}
				// 创建要显示的内容,创建一个单元格，第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容
				List<ProductTemplateParamsEntiy> templateParams = sqlService.queryProductTemplateParamsEntiy(batchLog.getTemplateId());
				// 首行标题
				Map<String, String> labelMap = new HashMap<String, String>();
				// 初始化首行
				assemblyData(sheet, templateParams, dataArr, labelMap, listRefDataEntity);
				threaddata.setDataArr(dataArr);
				threaddata.setLabelMap(labelMap);
				threaddata.setListRefDataEntity(listRefDataEntity);
				threaddata.setSheet(sheet);
				final CountDownLatch cdl = new CountDownLatch(list.size());
				threaddata.setSize(list.size());
				for (final BatchDataEntity batchDataEntity : list)
				{
					respText = batchDataEntity.getResponse();
					try
					{
						pool.execute(new Runnable()
						{
							@Override
							public void run()
							{
								try
								{
									// 对象锁，使其有序输出
									CommonsUtils.getLock();
									processData(batchDataEntity, threaddata);
									cdl.countDown();
								} catch (Exception e)
								{
									logger.error("", e);
								} finally
								{
									CommonsUtils.releaseLock();
								}
							}
						});
					} catch (Exception e)
					{
						logger.error("跑数据:erro---DownloadExcelController#exportExcelData，Exception,response={},error={}", respText, e);
						// 处理失败的，记录错误信息
						sheet.addCell(new Label(0, CommonsUtils.COLUMNS, "ERROR"));
						sheet.addCell(new Label(1, CommonsUtils.COLUMNS, respText));
						sheet.addCell(new Label(2, CommonsUtils.COLUMNS, "Exception"));
						sheet.addCell(new Label(3, CommonsUtils.COLUMNS, e.getStackTrace().toString()));
						CommonsUtils.COLUMNS++;
						throw e;
					}
				}
				cdl.await();
			} while (null != list && list.size() > 0);
			sheet = threaddata.getSheet();
		} catch (Exception e)
		{
			logger.error("跑数据:erro---DownloadExcelController#exportExcelData，Exception,response={},error={}", respText, e);
		} finally
		{
			// 每跑完一个批次，行数归零
			CommonsUtils.COLUMNS = 0;
			// sqlService.executeSql("update batch_data set export_status=0
			// where batch_no='" + batchNo + "'");
			// web浏览通过MIME类型判断文件是excel类型
			response.setContentType("application/vnd.ms-excel;charset=utf-8");
			response.setCharacterEncoding("utf-8");
			// Content-disposition属性设置成以附件方式进行下载
			response.setHeader("Content-disposition", "attachment;filename=" + "Id_" + batchNo + "_result.xls");
			workbook.write();
			if (null != workbook)
			{
				workbook.close();
			}
			if (null != os)
			{
				os.close();
			}
		}
		return null;
	}

	@RequestMapping(value = "getLastNumber")
	@ResponseBody
	public void getLastNumber(Model model, String batchNo, HttpServletResponse response) throws Exception
	{
		QueryNumber number = exportExcelBusiness.getLastNumber(batchNo);
		model.addAttribute("numer", number);
		JSONObject json = new JSONObject();
		json.put("totalNum", number.getTotalNum());
		json.put("haveRun", number.getHaveRun());
		json.put("lastNum", number.getLastNum());
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.print(json.toString());
		out.flush();
		out.close();
	}

	/**
	 * 跳转上传表格
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "updateExcel")
	@ResponseBody
	public ModelAndView updateExcel() throws Exception
	{
		return new ModelAndView("updateExcel");
	}

	/**
	 * 跳转跑数据
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "beginRunData")
	@ResponseBody
	public ModelAndView beginRunData() throws Exception
	{
		return new ModelAndView("beginRunData");
	}

	/**
	 * 跳转结果解析
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "analysisResult")
	@ResponseBody
	public ModelAndView analysisResult() throws Exception
	{
		return new ModelAndView("analysisResult");
	}

	/**
	 * 
	 * @param sheet
	 *            Excel一页
	 * @param templateParams
	 *            源数据的配置的模板
	 * @param dataArr
	 *            选中需要解析的结果
	 * @param labelMap
	 *            首行标题，接下来每一行都要用它来做参照复制
	 * @throws Exception
	 */
	private void assemblyData(WritableSheet sheet, List<ProductTemplateParamsEntiy> templateParams, String[] dataArr, Map<String, String> labelMap, List<RefDataEntity> listRefDataEntity) throws Exception
	{
		int count = 0;
		for (int m = 0; m < templateParams.size(); m++)
		{
			Label label = new Label(m, 0, templateParams.get(m).getFieldName());
			sheet.addCell(label);
			labelMap.put(Integer.toString(m).trim(), templateParams.get(m).getFieldKey());
			count++;
		}
		if (null != dataArr)
		{
			//
			// dataArr = sortArray(dataArr, listRefDataEntity);
			for (int k = 0; k < dataArr.length; k++)
			{
				Label label = new Label(count, 0, dataArr[k]);
				sheet.addCell(label);
				labelMap.put(Integer.toString(count).trim(), dataArr[k]);
				count++;
			}
		}
	}

	/**
	 * 将下载的结果集由外到内直接排序好，防止乱序导致后面数组死循环
	 * 
	 * @param dataArr
	 *            勾选下载的结果集
	 * @param listRefDataEntity
	 *            层级关系依赖
	 * @return
	 */
	private static String[] sortArray(String[] dataArr, List<RefDataEntity> listRefDataEntity)
	{
		// 先将dataArr根据依赖关系排序
		List<String> tempArr = new ArrayList<String>();
		int[] num = new int[listRefDataEntity.size()];// 存放ID
		Map<Integer, String> map = new HashMap<Integer, String>();
		for (RefDataEntity entity : listRefDataEntity)
		{
			map.put(entity.getId(), entity.getKeyId());
		}
		// 按keyId(层级关系排好了顺序)
		sortMap(map);
		//
		for (Integer id : map.keySet())
		{
			for (RefDataEntity entity : listRefDataEntity)
			{
				if (id == entity.getId())
				{
					for (String result : dataArr)
					{
						// 有外到里面匹配数据，放入新的排好的数组
						if (entity.getFiledName().equals(result.trim()))
						{
							tempArr.add(result);
						}
					}
				}
			}
		}
		// 将排好序的集合tempArr放入dataArr更新顺序
		for (int i = 0; i < tempArr.size(); i++)
		{
			dataArr[i] = tempArr.get(i);
		}
		return dataArr;
	}

	/**
	 * map按value排序
	 * 
	 * @param oldMap
	 * @return
	 */
	public static Map sortMap(Map oldMap)
	{
		ArrayList<Map.Entry<Integer, String>> list = new ArrayList<Map.Entry<Integer, String>>(oldMap.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<Integer, String>>()
		{
			@Override
			public int compare(Entry<Integer, String> arg0, Entry<Integer, String> arg1)
			{
				return Integer.parseInt(arg0.getValue()) - Integer.parseInt(arg1.getValue());
			}
		});
		Map newMap = new LinkedHashMap();
		for (int i = 0; i < list.size(); i++)
		{
			newMap.put(list.get(i).getKey(), list.get(i).getValue());
		}
		return newMap;
	}

	/**
	 * 多线程处理
	 * 
	 * @param batchDataEntity
	 * @param threaddata
	 */
	public void processData(final BatchDataEntity batchDataEntity, ThreadPrcessData threaddata)
	{
		String respJson = batchDataEntity.getResponse();
		List<RefDataEntity> listRefDataEntity = threaddata.getListRefDataEntity();
		String[] dataArr = threaddata.getDataArr();
		WritableSheet sheet = threaddata.getSheet();
		Map<String, String> labelMap = threaddata.getLabelMap();
		Map<String, Map> refMap = JsonUtils.pareseJson(respJson, listRefDataEntity);
		int size = threaddata.getSize() + ((null == dataArr) ? 0 : dataArr.length);
		// sheet下的一个lable 的长度
		try
		{
			JsonUtils.analyticData(refMap, respJson, size, sheet, dataArr, labelMap, batchDataEntity);
			// 值回填
			threaddata.setSheet(sheet);
		} catch (Exception e1)
		{
			logger.error("", e1);
		}
		CommonsUtils.COLUMNS++;
		// 更新数据
		batchDataEntity.setExportStatus("1");
		sqlService.updateBatchDataExportStaus(batchDataEntity);

	}
}

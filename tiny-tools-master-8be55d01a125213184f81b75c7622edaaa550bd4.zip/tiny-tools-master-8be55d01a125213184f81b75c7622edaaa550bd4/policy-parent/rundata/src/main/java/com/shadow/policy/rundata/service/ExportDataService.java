package com.shadow.policy.rundata.service;

import java.util.List;

import com.shadow.policy.rundata.entity.BatchDataEntity;
import com.shadow.policy.rundata.entity.QueryNumber;
import com.shadow.policy.rundata.entity.RefDataEntity;

public interface ExportDataService
{
	public List<RefDataEntity> getExportTemplete(String id);

	public List<BatchDataEntity> queryBatchDataEntity(BatchDataEntity batchDataEntity);

	public QueryNumber querySchedule(String batchNo);
}

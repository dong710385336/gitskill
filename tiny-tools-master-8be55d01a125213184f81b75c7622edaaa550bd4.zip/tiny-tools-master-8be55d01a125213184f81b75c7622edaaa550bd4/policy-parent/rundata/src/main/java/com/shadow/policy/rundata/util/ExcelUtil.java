package com.shadow.policy.rundata.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * ExcelUtil工具类
 * 
 * @author futingting
 *
 */
public class ExcelUtil {

	// public static HSSFWorkbook createExcel(RunAuthDataParamsConfigEntity
	// entity){
	// HSSFWorkbook wb=new HSSFWorkbook(); //创建一个Excel
	// HSSFSheet sheet=wb.createSheet("sheet1");//创建一个Sheet
	// HSSFRow row=sheet.createRow(0);//创建一个行
	//
	// String[] strings = entity.getParamsCn().split("，");//中文的逗号
	// for(int i=0; i<strings.length; i++){
	// HSSFCell cell=row.createCell((short)i); //创建一个单元格
	// cell.setCellValue(strings[i]); //设置值
	// }
	// return wb;
	// }

	public static Iterator<Row> getRows(String path, int sheetAt) throws IOException {
		boolean isE2007 = false;
		// 判断是否为excel2007格式
		if (path.endsWith("xlsx")) {
			isE2007 = true;
		}
		InputStream input = new FileInputStream(path);
		Workbook wb = null;
		if (isE2007) {
			wb = new XSSFWorkbook(input);
		} else {
			wb = new HSSFWorkbook(input);
		}
		Sheet sheet = wb.getSheetAt(sheetAt);// 获取第一个表单,sheetAt默认为0
		Iterator<Row> rows = sheet.rowIterator();// 获取第一个表单的迭代器
		return rows;
	}

	public static Iterator<Row> getRows(InputStream stream, int sheetAt) throws Exception {
		Workbook workbook = WorkbookFactory.create(stream);
		Sheet hssfSheet = workbook.getSheetAt(0); // 示意访问sheet
		// Workbook wb = new XSSFWorkbook(stream);
		// Sheet sheet = wb.getSheetAt(sheetAt);// 获取第一个表单,sheetAt默认为0
		Iterator<Row> rows = hssfSheet.rowIterator();// 获取第一个表单的迭代器
		return rows;
	}

	// 根据不同的类型进行转换为String类型进行返回
	public static String getCellValue(Cell cell) {
		String cellValue = "";
		switch (cell.getCellType()) {
		case XSSFCell.CELL_TYPE_BOOLEAN:
			cellValue = String.valueOf(cell.getBooleanCellValue()).trim();// 将boolan转换为String
			break;
		case XSSFCell.CELL_TYPE_FORMULA:
			cellValue = cell.getCellFormula().trim();
			break;
		case XSSFCell.CELL_TYPE_STRING:
			cellValue = cell.getStringCellValue().trim();
			break;
		case XSSFCell.CELL_TYPE_NUMERIC:
			cellValue = new BigDecimal(String.valueOf(cell.getNumericCellValue()).trim()).toPlainString();
			break;
		}
		return cellValue;
	}
}

package com.shadow.policy.rundata.business.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shadow.policy.rundata.business.ExportExcelBusiness;
import com.shadow.policy.rundata.entity.QueryNumber;
import com.shadow.policy.rundata.entity.RefDataEntity;
import com.shadow.policy.rundata.service.ExportDataService;
import com.shadow.policy.rundata.service.SqlService;

/**
 * 导出结果数据-excel
 * 
 * @author wangtao
 *
 */
@Service
public class ExportExcelBusinessImpl implements ExportExcelBusiness
{
	@Autowired
	private ExportDataService exportDataService;
	@Autowired
	private SqlService sqlService;

	@Override
	public List<RefDataEntity> getExportTemplete(String id)
	{

		List<RefDataEntity> refDataEntityList = exportDataService.getExportTemplete(id);

		return refDataEntityList;
	}

	@Override
	public QueryNumber getLastNumber(String batchNo)
	{
		QueryNumber number = exportDataService.querySchedule(batchNo);
		return number;
	}

}

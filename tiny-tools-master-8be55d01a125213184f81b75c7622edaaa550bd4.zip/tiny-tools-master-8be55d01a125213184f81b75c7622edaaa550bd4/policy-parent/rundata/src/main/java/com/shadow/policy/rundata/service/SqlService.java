package com.shadow.policy.rundata.service;

import java.util.List;
import java.util.Map;

import com.shadow.policy.rundata.entity.BatchDataEntity;
import com.shadow.policy.rundata.entity.BatchLogEntity;
import com.shadow.policy.rundata.entity.ProductTemplateEntity;
import com.shadow.policy.rundata.entity.ProductTemplateParamsEntiy;

/**
 * @author guanliming
 *
 */
public interface SqlService
{

	void executeSql(String sql);

	Integer queryCount(String tableName);

	List<Map<String, String>> query(String tableName, String start, String pageSize);

	void insertList(Map<String, Object> s1);

	void dropTable(String tableName);

	List<ProductTemplateParamsEntiy> queryProductTemplateParamsEntiy(String templateId);

	List<BatchDataEntity> queryBatchDataEntity(String batchNo);

	BatchLogEntity queryBatchLog(String batchNo);

	ProductTemplateEntity queryProductTemplate(String id);

	List<ProductTemplateEntity> queryProductTemplateList();

	void insertBatchLog(BatchLogEntity entity);

	void updateBatchLog(String batchNo);

	void updateBatchData(BatchDataEntity batchDataEntity);

	void updateBatchDataExportStaus(BatchDataEntity batchDataEntity);

	/**
	 * 查询条件：batchNo,ExportStatus
	 * @param batchDataEntity
	 * @return
	 */
	List<BatchDataEntity> queryByExportStatusAndBatchNO(BatchDataEntity batchDataEntity);

	/**
	 * 更新批次表
	 * @param batchLogEntity
	 */
	void updateBatchLogByEntity(BatchLogEntity batchLogEntity);

}

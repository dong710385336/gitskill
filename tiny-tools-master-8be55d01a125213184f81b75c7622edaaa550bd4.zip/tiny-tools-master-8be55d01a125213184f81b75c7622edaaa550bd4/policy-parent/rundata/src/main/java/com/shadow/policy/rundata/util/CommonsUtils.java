package com.shadow.policy.rundata.util;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CommonsUtils
{
	private static Lock lock = new ReentrantLock();;
	/**
	 * 定义Excel的列
	 */
	public static int COLUMNS = 0;

	public static void getLock()
	{
		lock.lock();
	}

	public static void releaseLock()
	{
		lock.unlock();
	}

}

package com.shadow.policy.rundata.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shadow.policy.rundata.dao.MyMapper;
import com.shadow.policy.rundata.entity.BatchDataEntity;
import com.shadow.policy.rundata.entity.BatchLogEntity;
import com.shadow.policy.rundata.entity.ProductTemplateEntity;
import com.shadow.policy.rundata.entity.ProductTemplateParamsEntiy;
import com.shadow.policy.rundata.service.SqlService;

/**
 * @author guanliming
 *
 */
@Service
public class SqlServiceImpl implements SqlService
{
	@Autowired
	private MyMapper mapper;

	@Override
	public void executeSql(String sql)
	{
		Map<String, String> mm = new HashMap<String, String>();
		mm.put("sql", sql);
		mapper.execute(mm);
	}

	@Override
	public Integer queryCount(String tableName)
	{
		return mapper.queryCount(tableName);
	}

	@Override
	public List<Map<String, String>> query(String tableName, String start, String pageSize)
	{
		return mapper.query(tableName, start, pageSize);
	}

	@Override
	public void insertList(Map<String, Object> s1)
	{
		mapper.insertList(s1);
	}

	@Override
	public void dropTable(String tableName)
	{
		mapper.dropTable(tableName);
	}

	@Override
	public List<ProductTemplateParamsEntiy> queryProductTemplateParamsEntiy(String templateId)
	{
		return mapper.queryProductTemplateParamsEntiy(templateId);
	}

	@Override
	public List<BatchDataEntity> queryBatchDataEntity(String batchNo)
	{
		return mapper.queryBatchDataEntity(batchNo);
	}

	@Override
	public BatchLogEntity queryBatchLog(String batchNo)
	{
		BatchLogEntity mm = mapper.queryBatchLog(batchNo);
		if (mm == null)
		{
			throw new RuntimeException("没有找到批次");
		}
		return mm;
	}

	@Override
	public ProductTemplateEntity queryProductTemplate(String id)
	{
		ProductTemplateEntity pt = mapper.queryProductTemplate(id);
		if (pt == null)
		{
			throw new RuntimeException();
		}
		return pt;
	}

	@Override
	public List<ProductTemplateEntity> queryProductTemplateList()
	{
		return mapper.queryProductTemplateList();
	}

	@Override
	public void insertBatchLog(BatchLogEntity entity)
	{
		mapper.insertBatchLog(entity);
	}

	@Override
	public void updateBatchLog(String batchNo)
	{
		mapper.updateBatchLog(batchNo);
	}

	@Override
	public void updateBatchData(BatchDataEntity batchDataEntity)
	{
		mapper.updateBatchData(batchDataEntity);
	}

	/**
	 * 更新export_status 为0
	 * 
	 * @param batchDataEntity
	 */
	@Override
	public void updateBatchDataExportStaus(BatchDataEntity batchDataEntity)
	{
		mapper.updateBatchExportStatusDataById(batchDataEntity);
	}

	/**
	 * 查询条件：batchNo,ExportStatus
	 * 
	 * 
	 */
	@Override
	public List<BatchDataEntity> queryByExportStatusAndBatchNO(BatchDataEntity batchDataEntity)
	{
		batchDataEntity.setLimitNum(mapper.selectLimitNum());
		return mapper.queryBatchDataEntityByEntity(batchDataEntity);
	}

	@Override
	public void updateBatchLogByEntity(BatchLogEntity batchLogEntity)
	{
		mapper.updateBatchLogByEntity(batchLogEntity);

	}

}

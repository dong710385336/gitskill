package com.shadow.policy.rundata.entity;

import lombok.Data;
import lombok.ToString;

@Data
@ToString(callSuper = true)
public class TestBairRong
{
	private String id;
	private String responseText;
}

package com.shadow.policy.rundata.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author guanliming
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ProductTemplateEntity {
	private Integer id;
	private String name;
	private String url;
	
}

DROP TABLE product_template;
DROP TABLE product_template_params;
DROP TABLE batch_data;
DROP TABLE batch_log;


CREATE TABLE `product_template` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '模板名称',
  `url` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '调用服务地址', 
  PRIMARY KEY (`id`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

CREATE TABLE `product_template_params` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `template_id` VARCHAR(255) NOT NULL COMMENT '跑数据接口模板名字',
  `field_key` VARCHAR(255) NOT NULL COMMENT '变量key',
  `field_name` VARCHAR(255) NOT NULL COMMENT '变量名',
  `field_name_cn` VARCHAR(255) NOT NULL COMMENT '变量中文名',
  PRIMARY KEY (`id`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

CREATE TABLE `batch_data` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `batch_no` VARCHAR(255) NOT NULL COMMENT '批次号',
  `status` VARCHAR(255) NOT NULL DEFAULT '0' COMMENT '状态,1-成功，2-失败，0-初始化',
  `param1` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数1',
  `param2` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数2',
  `param3` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数3',
  `param4` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数4',
  `param5` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数5',
  `param6` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数6',
  `param7` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数7',
  `param8` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数8',
  `param9` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数9',
  `param10` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数10',
  `param11` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数11',
  `param12` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数12',
  `param13` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数13',
  `param14` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数14',
  `param15` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数15',
  `param16` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '参数16',
  PRIMARY KEY (`id`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;

CREATE TABLE `batch_log` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `batch_no` VARCHAR(255) NOT NULL COMMENT '批次号',
  `template_id` INT not NULL COMMENT '模板编号',
  `execute_count` int default 0 COMMENT '执行次数',
  PRIMARY KEY (`id`)
) ENGINE=INNODB  DEFAULT CHARSET=utf8;
ALTER TABLE `batch_log` ADD UNIQUE (`batch_no`)


CREATE TABLE `t_ref_data` (
  `id` tinyint(32) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `key_Id` varchar(50) NOT NULL DEFAULT '' COMMENT '数值层级',
  `ref_id` tinyint(32) unsigned DEFAULT '0' COMMENT '依赖的ID',
  `parend_is_arr` tinyint(1) NOT NULL DEFAULT '0' COMMENT ' 上层是数组还是json   0-不是，1-数组，2-json',
  `filed_name` varchar(100) DEFAULT NULL,
  `filed_name_cn` varchar(100) DEFAULT NULL,
  `templete_id` varchar(100) DEFAULT NULL COMMENT '模板ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='数据结果关联信息';
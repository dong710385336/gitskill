package com.shadow.policy.rundata;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import com.shadow.policy.rundata.dto.Pair;
import com.shadow.policy.rundata.service.MyMapper;
import com.shadow.policy.rundata.util.MybatisUtil;

/**
 * @author paul
 *
 */
public class MainTest {

	@Test
	public void testExecute() {
		fail("Not yet implemented");
	}

	@Test
	public void testTransfer() {
		List<Pair> pairs = new ArrayList<Pair>();
		// String str =
		// "{\"batchNo\":\"aknyv2015113014345891937\",\"records\":[{\"dataBuildTime\":\"\",\"dataStatus\":\"\",\"erCode\":\"E000996\",\"erMsg\":\"(L)_(G)\",\"gradeQuery\":\"\",\"idNo\":\"340825198305064319\",\"idType\":\"0\",\"moneyBound\":\"\",\"name\":\"\",\"seqNo\":\"aknyv2015113014345891937\",\"sourceId\":\"\",\"state\":\"\"}],\"transNo\":\"2015113014345891937\"}";
		// String str =
		// "[{\"dataBuildTime\":\"\",\"dataStatus\":\"\",\"erCode\":\"E000996\",\"erMsg\":\"(L)_(G)\",\"gradeQuery\":\"\",\"idNo\":\"340825198305064319\",\"idType\":\"0\",\"moneyBound\":\"\",\"name\":\"\",\"seqNo\":\"aknyv2015113014345891937\",\"sourceId\":\"\",\"state\":\"\"}]";
		String str = "abc";
		Main.transfer(str, pairs);
		for (Pair pair : pairs) {
			System.out.println(pair.getKey() + ":" + pair.getValue());
		}
	}

	@Test
	public void testReturnNewKey() {
		List<Pair> pairs = Arrays.asList(new Pair("key1", "anyValue"), new Pair("key", "anyValue"),new Pair("key11", "anyValue"));
		System.out.println(Main.returnNewKey(null, "key", "anyValue", pairs));
	}

	@Test
	public void testCreateTable() {
		SqlSession sqlSession = MybatisUtil.getSqlSessionFactory().openSession();
		try {
			MyMapper userMapper = sqlSession.getMapper(MyMapper.class);
			 String sql = "CREATE TABLE `borrow` ("
			 + "`id` bigint(20) NOT NULL AUTO_INCREMENT,"
			 +
			 "`borrow_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '借款金额',"
			 + "`borrow_type` varchar(2) NOT NULL COMMENT '借款类型',"
			 + "`period` smallint(6) DEFAULT '0' COMMENT '期数',"
			 + "`borrow_user_id` bigint(20) NOT NULL COMMENT '借款人Id',"
			 + "`borrow_time` date NOT NULL COMMENT '借款时间',"
			 + "`on_account` decimal(10,2) DEFAULT '0.00' COMMENT '挂账',"
			 + "`repay_all` decimal(10,2) DEFAULT '0.00' COMMENT '已还总金额',"
			 + "`should_repay_all` decimal(10,2) DEFAULT '0.00' COMMENT '应还总金额',"
			 + "`completely_pay_off` char(1) DEFAULT 'N' COMMENT '是否还清(''Y'',''N'')',"
			 + "PRIMARY KEY (`id`)"
			 + ") ENGINE=InnoDB DEFAULT CHARSET=utf8";
			Map<String, String> mm = new HashMap<String, String>();
			mm.put("sql", sql);
			userMapper.createTable(mm);
		} catch (Exception e) {
			System.out.println("创建表" + "失败");
		} finally {
			sqlSession.close();
		}
	}

}

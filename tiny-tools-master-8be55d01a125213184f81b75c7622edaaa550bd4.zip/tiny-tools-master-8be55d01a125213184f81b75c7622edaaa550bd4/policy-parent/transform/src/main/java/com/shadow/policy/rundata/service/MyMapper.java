package com.shadow.policy.rundata.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * @author guanliming
 *
 */
public interface MyMapper {
	
	Integer queryCount(@Param("tableName")String tableName);

	void createTable(Map<String, String> sql1);

	List<Map<String, String>> query(@Param("tableName")String tableName,@Param("start") String start,@Param("pageSize") String pageSize);

	void insertList(Map<String, Object> s1);
	
	void dropTable(@Param("tableName")String tableName);

}

package com.shadow.policy.rundata;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.shadow.policy.rundata.dto.Pair;
import com.shadow.policy.rundata.service.MyMapper;
import com.shadow.policy.rundata.util.MybatisUtil;

/**
 * @author guanliming
 *
 */
public class Main {
	private static SqlSessionFactory sqlSessionFactory = null;
	private static Logger logger = LoggerFactory.getLogger(Main.class);
	/**
	 * 建表主键名
	 */
	private static String primaryKeyName = null;
	/**
	 * 建表倒计数
	 */
	private static Integer createTableCountDown = null;
	/**
	 * 建表列的统一长度
	 */
	private static String columnLength = null;
	/**
	 * 批处理数量
	 */
	private static Integer batchOperateSize = null;

	static {
		sqlSessionFactory = MybatisUtil.getSqlSessionFactory();
			Properties p = new Properties();
			try {
				p.load(Main.class.getClassLoader().getResourceAsStream(
						"my.properties"));
				primaryKeyName = p.getProperty("primaryKeyName");
				createTableCountDown = Integer.parseInt(p
						.getProperty("createTableCountDown"));
				columnLength = p.getProperty("columnLength");
				batchOperateSize = Integer.parseInt(p
						.getProperty("batchOperateSize"));
			} catch (Exception e) {
				// System.out.println("init failure");
				logger.error("init failure:{}", e);
			}
		}

	public static void main(String[] args) {
		// String tableName = "t_third_service_log_his";
		String tableName = null;
		if (args != null && args.length > 0 && StringUtils.isNotBlank(args[0])) {
			tableName = args[0];
		} else {
			logger.info("请输入待解析的表名");
			return;
		}
		String createTable = tableName + "_analysis";
		if (args != null && args.length > 1 && StringUtils.isNotBlank(args[1])) {
			if (Boolean.valueOf(args[1])) {
				Main.dropTable(createTable);
			}
		}

		execute(createTable, tableName);
		logger.info("执行完成!");
	}

	public static void execute(String createTableName, String queryTableName) {
		List<Pair> s1 = new ArrayList<Pair>();
		SqlSession sqlSession = sqlSessionFactory.openSession();
		try {
			MyMapper userMapper = sqlSession.getMapper(MyMapper.class);
			Integer count = userMapper.queryCount(queryTableName);
			Integer yushu = count % batchOperateSize;
			Integer cal = count / batchOperateSize;
			if (yushu != 0) {
				cal++;
			}
			for (int i = 1; i <= cal; i++) {
				List<Map<String, String>> lists = userMapper.query(
						queryTableName,
						String.valueOf((i - 1) * batchOperateSize),
						String.valueOf(batchOperateSize));
				for (Map<String, String> mm : lists) {// mm:一行的数据
					for (Entry<String, String> ee : mm.entrySet()) {// ee:一行中的列名和值的entry
						try {
							Main.transfer(ee.getValue(), s1);
						} catch (Exception e) {
							s1.add(new Pair(Main.returnNewKey(ee.getKey()
									.length(), ee.getKey(), String.valueOf(ee
									.getValue()), s1), String.valueOf(ee
									.getValue())));
						}
					}
					// String req = mm.get("request_text");
					// JSONObject reqJo = JSONObject.parseObject(req);
					// String res = mm.get("response_text");
					// transfer(res, s1);
					createTable(s1, createTableName);
					try {
						insertData(createTableName, s1);
					} catch (Exception e) {
						// System.out.println("插入数据失败：" + e.toString());
						logger.error("插入数据失败：{}", e);
					}
					s1.clear();
				}
			}
		} finally {
			sqlSession.close();
		}
	}

	private static void dropTable(String createTableName) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		try {
			MyMapper userMapper = sqlSession.getMapper(MyMapper.class);
			userMapper.dropTable(createTableName);
			sqlSession.commit();
		} catch (Exception e) {
			logger.error("删除表失败：{}", e);
		} finally {
			sqlSession.close();
		}
	}

	private static void insertData(String createTableName, List<Pair> s1) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		try {
			MyMapper userMapper = sqlSession.getMapper(MyMapper.class);
			Map<String, Object> m = new HashMap<String, Object>();
			m.put("tableName", createTableName);
			m.put("entitys", s1);
			userMapper.insertList(m);
			sqlSession.commit();
		} finally {
			sqlSession.close();
		}
	}

	private static void createTable(List<Pair> s1, String tableName) {
		if (createTableCountDown > 0) {
			createTable(getCreateTableSql(s1, tableName));
		}
		createTableCountDown--;
	}

	private static void createTable(String sql) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		try {
			MyMapper userMapper = sqlSession.getMapper(MyMapper.class);
			Map<String, String> mm = new HashMap<String, String>();
			mm.put("sql", sql);
			userMapper.createTable(mm);
		} catch (Exception e) {
			// System.out.println("创建表" + "失败");
			logger.error("创建表" + "失败");
		} finally {
			sqlSession.close();
		}
	}

	private static String getCreateTableSql(List<Pair> s1, String tableName) {
		StringBuilder sb = new StringBuilder();
		sb.append("create table ");
		sb.append(tableName + " ( ");
		sb.append(primaryKeyName + " bigint(20) NOT NULL AUTO_INCREMENT,");
		for (Pair p : s1) {
			sb.append(getRow(p.getKey()));
		}
		sb.append("PRIMARY KEY (" + primaryKeyName + ") ");
		sb.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
		return sb.toString();
	}

	private static String getRow(String key) {
		StringBuilder sb = new StringBuilder(key);
		sb.append(" varchar(" + columnLength + ")");
		sb.append(" DEFAULT '', ");
		return sb.toString();
	}

	/**
	 * 将str转换成Pair型List
	 *
	 * @param str
	 * @param pp
	 */
	public static void transfer(String str, List<Pair> pp) {
		try {
			JSONObject resJo = JSONObject.parseObject(str);
			if (resJo != null) {
				Set<Entry<String, Object>> en = resJo.entrySet();
				for (Entry<String, Object> each : en) {
					String key = returnNewKey(each.getKey().length(),
							each.getKey(), each.getValue(), pp);
					if (each.getValue() instanceof String) {
						pp.add(new Pair(key, String.valueOf(each.getValue())));
						continue;
					}
					if (each.getValue() != null
							&& each.getValue() instanceof JSONArray) {
						// JSONArray ja = JSONObject.parseArray(each.getValue()
						// .toString());
						JSONArray ja = (JSONArray) each.getValue();
						Iterator<Object> js = ja.iterator();
						while (js.hasNext()) {
							Object obj = js.next();
							Main.transfer(obj.toString(), pp);
						}

					}
				}
			}
		} catch (Exception e) {
			JSONArray resJo;
			try {
				resJo = JSONObject.parseArray(str);
			} catch (Exception e2) {
				throw new RuntimeException("该字符串不是JSON字符串", e2);
			}
			Iterator<Object> js = resJo.iterator();
			while (js.hasNext()) {
				Object obj = js.next();
				String str1 = obj.toString();
				Main.transfer(str1, pp);
			}
		}
	}

	/**
	 * 返回待插入的key
	 * 
	 * @param initKeyLength
	 * @param initKey
	 * @param value
	 * @param pp
	 *
	 * @return
	 */
	public static String returnNewKey(Integer initKeyLength, String initKey,
			Object value, List<Pair> pp) {
		String key = initKey;
		if (pp.contains(new Pair(key, String.valueOf(value)))) {
			if (key.length() == initKeyLength) {
				key = key + 1;
			} else {
				String keyMain = key.substring(0, initKeyLength);
				String keyIndex = key.substring(initKeyLength);
				if (StringUtils.isNotBlank(keyIndex)) {
					Integer index = Integer.parseInt(keyIndex);
					index++;
					key = keyMain + index;
				}
			}
			return returnNewKey(initKeyLength, key, value, pp);
		}
		return key;
	}

}
